public class mu extends mw {
   private final zw a;

   public mu(String var1, String var2, eu var3, zw var4) {
      super(var1 + var2, var3);
      this.a = var4;
      int var5 = zw.b(var4);
      if (var5 != 0) {
         auu.a.put(var1 + var5, this.k());
      }

   }

   public zw a() {
      return this.a;
   }
}
