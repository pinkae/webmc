public abstract class uu extends pk {
   public uu(adm var1) {
      super(var1);
   }
}
