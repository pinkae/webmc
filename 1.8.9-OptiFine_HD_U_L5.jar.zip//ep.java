public interface ep {
   void a(eu var1);
}
