public class ael extends ady {
   public ael(int var1) {
      super(var1);
      this.as.A = -100;
      this.as.B = -100;
      this.as.C = -100;
      this.as.E = 1;
      this.as.K = 1;
      this.ak = afi.bw.Q();
      this.at.clear();
      this.au.clear();
      this.av.clear();
      this.au.add(new ady.c(tr.class, 8, 4, 8));
   }
}
