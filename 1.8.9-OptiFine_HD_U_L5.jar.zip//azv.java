import java.util.List;

public class azv extends azu {
   public azv(ave var1, int var2, int var3, List<azp> var4) {
      super(var1, var2, var3, var4);
   }

   protected String e() {
      return bnq.a("resourcePack.selected.title");
   }
}
