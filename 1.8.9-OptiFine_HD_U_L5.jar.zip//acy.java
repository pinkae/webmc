public interface acy {
   void a_(wn var1);

   wn v_();

   ada b_(wn var1);

   void a(ada var1);

   void a(acz var1);

   void a_(zx var1);

   eu f_();
}
