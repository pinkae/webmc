public class abr {
   private Object[][] a;

   public abr() {
      this.a = new Object[][]{{afi.R, new zx(zy.k, 9)}, {afi.S, new zx(zy.j, 9)}, {afi.ah, new zx(zy.i, 9)}, {afi.bT, new zx(zy.bO, 9)}, {afi.y, new zx(zy.aW, 9, zd.l.b())}, {afi.cn, new zx(zy.aC, 9)}, {afi.cA, new zx(zy.h, 9, 0)}, {afi.cx, new zx(zy.O, 9)}, {afi.cE, new zx(zy.aM, 9)}};
   }

   public void a(abt var1) {
      for(int var2 = 0; var2 < this.a.length; ++var2) {
         afh var3 = (afh)this.a[var2][0];
         zx var4 = (zx)this.a[var2][1];
         var1.a(new zx(var3), "###", "###", "###", '#', var4);
         var1.a(var4, "#", '#', var3);
      }

      var1.a(new zx(zy.k), "###", "###", "###", '#', zy.bx);
      var1.a(new zx(zy.bx, 9), "#", '#', zy.k);
   }
}
