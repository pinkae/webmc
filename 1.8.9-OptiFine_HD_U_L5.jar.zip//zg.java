public class zg extends zw {
   public zg() {
      this.h = 16;
      this.a(yz.l);
   }

   public zx a(zx var1, adm var2, wn var3) {
      if (!var3.bA.d) {
         --var1.b;
      }

      var2.a((pk)var3, "random.bow", 0.5F, 0.4F / (g.nextFloat() * 0.4F + 0.8F));
      if (!var2.D) {
         var2.d((pk)(new wz(var2, var3)));
      }

      var3.b(na.ad[zw.b((zw)this)]);
      return var1;
   }
}
