package net.minecraft.server;

import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import com.google.common.collect.Queues;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListenableFutureTask;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.GameProfileRepository;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufOutputStream;
import io.netty.buffer.Unpooled;
import io.netty.handler.codec.base64.Base64;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.Proxy;
import java.security.KeyPair;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import javax.imageio.ImageIO;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class MinecraftServer implements Runnable, .m, .od, .os {
   private static final Logger k = LogManager.getLogger();
   public static final File a = new File("usercache.json");
   private static MinecraftServer l;
   private final .atr m;
   private final .or n = new .or("server", this, az());
   private final File o;
   private final List<.km> p = Lists.newArrayList();
   protected final .l b;
   public final .nt c = new .nt();
   private final .ll q;
   private final .js r = new .js();
   private final Random s = new Random();
   private int u = -1;
   public .le[] d;
   private .lx v;
   private boolean w = true;
   private boolean x;
   private int y;
   protected final Proxy e;
   public String f;
   public int g;
   private boolean z;
   private boolean A;
   private boolean B;
   private boolean C;
   private boolean D;
   private String E;
   private int F;
   private int G = 0;
   public final long[] h = new long[100];
   public long[][] i;
   private KeyPair H;
   private String I;
   private String J;
   private String K;
   private boolean L;
   private boolean M;
   private boolean N;
   private String O = "";
   private String P = "";
   private boolean Q;
   private long R;
   private String S;
   private boolean T;
   private boolean U;
   private final YggdrasilAuthenticationService V;
   private final MinecraftSessionService W;
   private long X = 0L;
   private final GameProfileRepository Y;
   private final .lt Z;
   protected final Queue<FutureTask<?>> j = Queues.newArrayDeque();
   private Thread aa;
   private long ab = az();

   public MinecraftServer(Proxy var1, File var2) {
      this.e = var1;
      l = this;
      this.o = null;
      this.q = null;
      this.Z = new .lt(this, var2);
      this.b = null;
      this.m = null;
      this.V = new YggdrasilAuthenticationService(var1, UUID.randomUUID().toString());
      this.W = this.V.createMinecraftSessionService();
      this.Y = this.V.createProfileRepository();
   }

   public MinecraftServer(File var1, Proxy var2, File var3) {
      this.e = var2;
      l = this;
      this.o = var1;
      this.q = new .ll(this);
      this.Z = new .lt(this, var3);
      this.b = this.h();
      this.m = new .atk(var1);
      this.V = new YggdrasilAuthenticationService(var2, UUID.randomUUID().toString());
      this.W = this.V.createMinecraftSessionService();
      this.Y = this.V.createProfileRepository();
   }

   protected .bd h() {
      return new .bd();
   }

   protected abstract boolean i() throws IOException;

   protected void a(String var1) {
      if (this.Y().b(var1)) {
         k.info("Converting map!");
         this.b("menu.convertingLevel");
         this.Y().a(var1, new .nu() {
            private long b = MinecraftServer.az();

            public void a(String var1) {
            }

            public void b(String var1) {
            }

            public void a(int var1) {
               if (MinecraftServer.az() - this.b >= 1000L) {
                  this.b = MinecraftServer.az();
                  MinecraftServer.k.info("Converting... " + var1 + "%");
               }

            }

            public void a() {
            }

            public void c(String var1) {
            }
         });
      }

   }

   protected synchronized void b(String var1) {
      this.S = var1;
   }

   public synchronized String j() {
      return this.S;
   }

   protected void a(String var1, String var2, long var3, .adr var5, String var6) {
      this.a(var1);
      this.b("menu.loadingLevel");
      this.d = new .le[3];
      this.i = new long[this.d.length][100];
      .atp var7 = this.m.a(var1, true);
      this.a(this.U(), var7);
      .ato var9 = var7.d();
      .adp var8;
      if (var9 == null) {
         if (this.X()) {
            var8 = .kx.a;
         } else {
            var8 = new .adp(var3, this.m(), this.l(), this.o(), var5);
            var8.a(var6);
            if (this.M) {
               var8.a();
            }
         }

         var9 = new .ato(var8, var2);
      } else {
         var9.a(var2);
         var8 = new .adp(var9);
      }

      for(int var10 = 0; var10 < this.d.length; ++var10) {
         int var11 = 0;
         if (var10 == 1) {
            var11 = -1;
         }

         if (var10 == 2) {
            var11 = 1;
         }

         if (var10 == 0) {
            if (this.X()) {
               this.d[var10] = (.le)(new .kx(this, var7, var9, var11, this.c)).b();
            } else {
               this.d[var10] = (.le)(new .le(this, var7, var9, var11, this.c)).b();
            }

            this.d[var10].a(var8);
         } else {
            this.d[var10] = (.le)(new .kz(this, var7, var11, this.d[0], this.c)).b();
         }

         this.d[var10].a((.ado)(new .lb(this, this.d[var10])));
         if (!this.T()) {
            this.d[var10].P().a(this.m());
         }
      }

      this.v.a(this.d);
      this.a(this.n());
      this.k();
   }

   protected void k() {
      int var1 = true;
      int var2 = true;
      int var3 = true;
      int var4 = true;
      int var5 = 0;
      this.b("menu.generatingTerrain");
      int var6 = 0;
      k.info("Preparing start region for level " + var6);
      .le var7 = this.d[var6];
      .cj var8 = var7.M();
      long var9 = az();

      for(int var11 = -192; var11 <= 192 && this.v(); var11 += 16) {
         for(int var12 = -192; var12 <= 192 && this.v(); var12 += 16) {
            long var13 = az();
            if (var13 - var9 > 1000L) {
               this.a_("Preparing spawn area", var5 * 100 / 625);
               var9 = var13;
            }

            ++var5;
            var7.b.c(var8.n() + var11 >> 4, var8.p() + var12 >> 4);
         }
      }

      this.s();
   }

   protected void a(String var1, .atp var2) {
      File var3 = new File(var2.b(), "resources.zip");
      if (var3.isFile()) {
         this.a_("level://" + var1 + "/" + var3.getName(), "");
      }

   }

   public abstract boolean l();

   public abstract .adp.a m();

   public abstract .oj n();

   public abstract boolean o();

   public abstract int p();

   public abstract boolean q();

   public abstract boolean r();

   protected void a_(String var1, int var2) {
      this.f = var1;
      this.g = var2;
      k.info(var1 + ": " + var2 + "%");
   }

   protected void s() {
      this.f = null;
      this.g = 0;
   }

   protected void a(boolean var1) {
      if (!this.N) {
         .le[] var2 = this.d;
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            .le var5 = var2[var4];
            if (var5 != null) {
               if (!var1) {
                  k.info("Saving chunks for level '" + var5.P().k() + "'/" + var5.t.k());
               }

               try {
                  var5.a(true, (.nu)null);
               } catch (.adn var7) {
                  k.warn(var7.getMessage());
               }
            }
         }

      }
   }

   public void t() {
      if (!this.N) {
         k.info("Stopping server");
         if (this.aq() != null) {
            this.aq().b();
         }

         if (this.v != null) {
            k.info("Saving players");
            this.v.j();
            this.v.u();
         }

         if (this.d != null) {
            k.info("Saving worlds");
            this.a(false);

            for(int var1 = 0; var1 < this.d.length; ++var1) {
               .le var2 = this.d[var1];
               var2.o();
            }
         }

         if (this.n.d()) {
            this.n.e();
         }

      }
   }

   public boolean v() {
      return this.w;
   }

   public void w() {
      this.w = false;
   }

   protected void x() {
      l = this;
   }

   public void run() {
      try {
         if (this.i()) {
            this.ab = az();
            long var1 = 0L;
            this.r.a((.eu)(new .fa(this.E)));
            this.r.a(new .js.c("1.8.9", 47));
            this.a(this.r);

            while(this.w) {
               long var48 = az();
               long var5 = var48 - this.ab;
               if (var5 > 2000L && this.ab - this.R >= 15000L) {
                  k.warn("Can't keep up! Did the system time change, or is the server overloaded? Running {}ms behind, skipping {} tick(s)", new Object[]{var5, var5 / 50L});
                  var5 = 2000L;
                  this.R = this.ab;
               }

               if (var5 < 0L) {
                  k.warn("Time ran backwards! Did the system time change?");
                  var5 = 0L;
               }

               var1 += var5;
               this.ab = var48;
               if (this.d[0].f()) {
                  this.A();
                  var1 = 0L;
               } else {
                  while(var1 > 50L) {
                     var1 -= 50L;
                     this.A();
                  }
               }

               Thread.sleep(Math.max(1L, 50L - var1));
               this.Q = true;
            }
         } else {
            this.a((.b)null);
         }
      } catch (Throwable var46) {
         k.error("Encountered an unexpected exception", var46);
         .b var2 = null;
         if (var46 instanceof .e) {
            var2 = this.b(((.e)var46).a());
         } else {
            var2 = this.b(new .b("Exception in server tick loop", var46));
         }

         File var3 = new File(new File(this.y(), "crash-reports"), "crash-" + (new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss")).format(new Date()) + "-server.txt");
         if (var2.a(var3)) {
            k.error("This crash report has been saved to: " + var3.getAbsolutePath());
         } else {
            k.error("We were unable to save this crash report to disk.");
         }

         this.a(var2);
      } finally {
         try {
            this.x = true;
            this.t();
         } catch (Throwable var44) {
            k.error("Exception stopping the server", var44);
         } finally {
            this.z();
         }

      }

   }

   private void a(.js var1) {
      File var2 = this.d("server-icon.png");
      if (var2.isFile()) {
         ByteBuf var3 = Unpooled.buffer();

         try {
            BufferedImage var4 = ImageIO.read(var2);
            Validate.validState(var4.getWidth() == 64, "Must be 64 pixels wide", new Object[0]);
            Validate.validState(var4.getHeight() == 64, "Must be 64 pixels high", new Object[0]);
            ImageIO.write(var4, "PNG", new ByteBufOutputStream(var3));
            ByteBuf var5 = Base64.encode(var3);
            var1.a("data:image/png;base64," + var5.toString(Charsets.UTF_8));
         } catch (Exception var9) {
            k.error("Couldn't load server icon", var9);
         } finally {
            var3.release();
         }
      }

   }

   public File y() {
      return new File(".");
   }

   protected void a(.b var1) {
   }

   protected void z() {
   }

   public void A() {
      long var1 = System.nanoTime();
      ++this.y;
      if (this.T) {
         this.T = false;
         this.c.a = true;
         this.c.a();
      }

      this.c.a("root");
      this.B();
      if (var1 - this.X >= 5000000000L) {
         this.X = var1;
         this.r.a(new .js.a(this.J(), this.I()));
         GameProfile[] var3 = new GameProfile[Math.min(this.I(), 12)];
         int var4 = .ns.a((Random)this.s, 0, this.I() - var3.length);

         for(int var5 = 0; var5 < var3.length; ++var5) {
            var3[var5] = ((.lf)this.v.v().get(var4 + var5)).cd();
         }

         Collections.shuffle(Arrays.asList(var3));
         this.r.b().a(var3);
      }

      if (this.y % 900 == 0) {
         this.c.a("save");
         this.v.j();
         this.a(true);
         this.c.b();
      }

      this.c.a("tallying");
      this.h[this.y % 100] = System.nanoTime() - var1;
      this.c.b();
      this.c.a("snooper");
      if (!this.n.d() && this.y > 100) {
         this.n.a();
      }

      if (this.y % 6000 == 0) {
         this.n.b();
      }

      this.c.b();
      this.c.b();
   }

   public void B() {
      this.c.a("jobs");
      synchronized(this.j) {
         while(!this.j.isEmpty()) {
            .g.a((FutureTask)this.j.poll(), k);
         }
      }

      this.c.c("levels");

      int var1;
      for(var1 = 0; var1 < this.d.length; ++var1) {
         long var2 = System.nanoTime();
         if (var1 == 0 || this.C()) {
            .le var4 = this.d[var1];
            this.c.a(var4.P().k());
            if (this.y % 20 == 0) {
               this.c.a("timeSync");
               this.v.a((.ff)(new .hu(var4.K(), var4.L(), var4.Q().b("doDaylightCycle"))), var4.t.q());
               this.c.b();
            }

            this.c.a("tick");

            .b var6;
            try {
               var4.c();
            } catch (Throwable var8) {
               var6 = .b.a(var8, "Exception ticking world");
               var4.a((.b)var6);
               throw new .e(var6);
            }

            try {
               var4.i();
            } catch (Throwable var7) {
               var6 = .b.a(var7, "Exception ticking world entities");
               var4.a((.b)var6);
               throw new .e(var6);
            }

            this.c.b();
            this.c.a("tracker");
            var4.s().a();
            this.c.b();
            this.c.b();
         }

         this.i[var1][this.y % 100] = System.nanoTime() - var2;
      }

      this.c.c("connection");
      this.aq().c();
      this.c.c("players");
      this.v.e();
      this.c.c("tickables");

      for(var1 = 0; var1 < this.p.size(); ++var1) {
         ((.km)this.p.get(var1)).c();
      }

      this.c.b();
   }

   public boolean C() {
      return true;
   }

   public void D() {
      this.aa = new Thread(this, "Server thread");
      this.aa.start();
   }

   public File d(String var1) {
      return new File(this.y(), var1);
   }

   public void f(String var1) {
      k.warn(var1);
   }

   public .le a(int var1) {
      if (var1 == -1) {
         return this.d[1];
      } else {
         return var1 == 1 ? this.d[2] : this.d[0];
      }
   }

   public String H() {
      return "1.8.9";
   }

   public int I() {
      return this.v.o();
   }

   public int J() {
      return this.v.p();
   }

   public String[] K() {
      return this.v.f();
   }

   public GameProfile[] L() {
      return this.v.g();
   }

   public String getServerModName() {
      return "vanilla";
   }

   public .b b(.b var1) {
      var1.g().a("Profiler Position", new Callable<String>() {
         public String a() throws Exception {
            return MinecraftServer.this.c.a ? MinecraftServer.this.c.c() : "N/A (disabled)";
         }

         // $FF: synthetic method
         public Object call() throws Exception {
            return this.a();
         }
      });
      if (this.v != null) {
         var1.g().a("Player Count", new Callable<String>() {
            public String a() {
               return MinecraftServer.this.v.o() + " / " + MinecraftServer.this.v.p() + "; " + MinecraftServer.this.v.v();
            }

            // $FF: synthetic method
            public Object call() throws Exception {
               return this.a();
            }
         });
      }

      return var1;
   }

   public List<String> a(.m var1, String var2, .cj var3) {
      List<String> var4 = Lists.newArrayList();
      if (var2.startsWith("/")) {
         var2 = var2.substring(1);
         boolean var11 = !var2.contains(" ");
         List<String> var12 = this.b.a(var1, var2, var3);
         if (var12 != null) {
            Iterator var13 = var12.iterator();

            while(var13.hasNext()) {
               String var14 = (String)var13.next();
               if (var11) {
                  var4.add("/" + var14);
               } else {
                  var4.add(var14);
               }
            }
         }

         return var4;
      } else {
         String[] var5 = var2.split(" ", -1);
         String var6 = var5[var5.length - 1];
         String[] var7 = this.v.f();
         int var8 = var7.length;

         for(int var9 = 0; var9 < var8; ++var9) {
            String var10 = var7[var9];
            if (.i.a(var6, var10)) {
               var4.add(var10);
            }
         }

         return var4;
      }
   }

   public static MinecraftServer N() {
      return l;
   }

   public boolean O() {
      return this.o != null;
   }

   public String e_() {
      return "Server";
   }

   public void a(.eu var1) {
      k.info(var1.c());
   }

   public boolean a(int var1, String var2) {
      return true;
   }

   public .l P() {
      return this.b;
   }

   public KeyPair Q() {
      return this.H;
   }

   public String S() {
      return this.I;
   }

   public void i(String var1) {
      this.I = var1;
   }

   public boolean T() {
      return this.I != null;
   }

   public String U() {
      return this.J;
   }

   public void j(String var1) {
      this.J = var1;
   }

   public void k(String var1) {
      this.K = var1;
   }

   public String V() {
      return this.K;
   }

   public void a(KeyPair var1) {
      this.H = var1;
   }

   public void a(.oj var1) {
      for(int var2 = 0; var2 < this.d.length; ++var2) {
         .adm var3 = this.d[var2];
         if (var3 != null) {
            if (var3.P().t()) {
               var3.P().a(.oj.d);
               var3.a(true, true);
            } else if (this.T()) {
               var3.P().a(var1);
               var3.a(var3.aa() != .oj.a, true);
            } else {
               var3.P().a(var1);
               var3.a(this.W(), this.A);
            }
         }
      }

   }

   protected boolean W() {
      return true;
   }

   public boolean X() {
      return this.L;
   }

   public void b(boolean var1) {
      this.L = var1;
   }

   public void c(boolean var1) {
      this.M = var1;
   }

   public .atr Y() {
      return this.m;
   }

   public void aa() {
      this.N = true;
      this.Y().d();

      for(int var1 = 0; var1 < this.d.length; ++var1) {
         .le var2 = this.d[var1];
         if (var2 != null) {
            var2.o();
         }
      }

      this.Y().e(this.d[0].O().g());
      this.w();
   }

   public String ab() {
      return this.O;
   }

   public String ac() {
      return this.P;
   }

   public void a_(String var1, String var2) {
      this.O = var1;
      this.P = var2;
   }

   public void a(.or var1) {
      var1.a("whitelist_enabled", false);
      var1.a("whitelist_count", 0);
      if (this.v != null) {
         var1.a("players_current", this.I());
         var1.a("players_max", this.J());
         var1.a("players_seen", this.v.q().length);
      }

      var1.a("uses_auth", this.z);
      var1.a("gui_state", this.as() ? "enabled" : "disabled");
      var1.a("run_time", (az() - var1.g()) / 60L * 1000L);
      var1.a("avg_tick_ms", (int)(.ns.a(this.h) * 1.0E-6D));
      int var2 = 0;
      if (this.d != null) {
         for(int var3 = 0; var3 < this.d.length; ++var3) {
            if (this.d[var3] != null) {
               .le var4 = this.d[var3];
               .ato var5 = var4.P();
               var1.a("world[" + var2 + "][dimension]", var4.t.q());
               var1.a("world[" + var2 + "][mode]", var5.r());
               var1.a("world[" + var2 + "][difficulty]", var4.aa());
               var1.a("world[" + var2 + "][hardcore]", var5.t());
               var1.a("world[" + var2 + "][generator_name]", var5.u().a());
               var1.a("world[" + var2 + "][generator_version]", var5.u().d());
               var1.a("world[" + var2 + "][height]", this.F);
               var1.a("world[" + var2 + "][chunks_loaded]", var4.N().g());
               ++var2;
            }
         }
      }

      var1.a("worlds", var2);
   }

   public void b(.or var1) {
      var1.b("singleplayer", this.T());
      var1.b("server_brand", this.getServerModName());
      var1.b("gui_supported", GraphicsEnvironment.isHeadless() ? "headless" : "supported");
      var1.b("dedicated", this.ae());
   }

   public boolean ad() {
      return true;
   }

   public abstract boolean ae();

   public boolean af() {
      return this.z;
   }

   public void d(boolean var1) {
      this.z = var1;
   }

   public boolean ag() {
      return this.A;
   }

   public void e(boolean var1) {
      this.A = var1;
   }

   public boolean ah() {
      return this.B;
   }

   public abstract boolean ai();

   public void f(boolean var1) {
      this.B = var1;
   }

   public boolean aj() {
      return this.C;
   }

   public void g(boolean var1) {
      this.C = var1;
   }

   public boolean ak() {
      return this.D;
   }

   public void h(boolean var1) {
      this.D = var1;
   }

   public abstract boolean al();

   public String am() {
      return this.E;
   }

   public void l(String var1) {
      this.E = var1;
   }

   public int an() {
      return this.F;
   }

   public void c(int var1) {
      this.F = var1;
   }

   public boolean ao() {
      return this.x;
   }

   public .lx ap() {
      return this.v;
   }

   public void a(.lx var1) {
      this.v = var1;
   }

   public void a(.adp.a var1) {
      for(int var2 = 0; var2 < this.d.length; ++var2) {
         N().d[var2].P().a(var1);
      }

   }

   public .ll aq() {
      return this.q;
   }

   public boolean ar() {
      return this.Q;
   }

   public boolean as() {
      return false;
   }

   public abstract String a(.adp.a var1, boolean var2);

   public int at() {
      return this.y;
   }

   public void au() {
      this.T = true;
   }

   public .or av() {
      return this.n;
   }

   public .cj c() {
      return .cj.a;
   }

   public .aui d() {
      return new .aui(0.0D, 0.0D, 0.0D);
   }

   public .adm e() {
      return this.d[0];
   }

   public .pk f() {
      return null;
   }

   public int aw() {
      return 16;
   }

   public boolean a(.adm var1, .cj var2, .wn var3) {
      return false;
   }

   public boolean ax() {
      return this.U;
   }

   public Proxy ay() {
      return this.e;
   }

   public static long az() {
      return System.currentTimeMillis();
   }

   public int aA() {
      return this.G;
   }

   public void d(int var1) {
      this.G = var1;
   }

   public .eu f_() {
      return new .fa(this.e_());
   }

   public boolean aB() {
      return true;
   }

   public MinecraftSessionService aD() {
      return this.W;
   }

   public GameProfileRepository aE() {
      return this.Y;
   }

   public .lt aF() {
      return this.Z;
   }

   public .js aG() {
      return this.r;
   }

   public void aH() {
      this.X = 0L;
   }

   public .pk a(UUID var1) {
      .le[] var2 = this.d;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         .le var5 = var2[var4];
         if (var5 != null) {
            .pk var6 = var5.a(var1);
            if (var6 != null) {
               return var6;
            }
         }
      }

      return null;
   }

   public boolean u_() {
      return N().d[0].Q().b("sendCommandFeedback");
   }

   public void a(.n.a var1, int var2) {
   }

   public int aI() {
      return 29999984;
   }

   public <V> ListenableFuture<V> a(Callable<V> var1) {
      Validate.notNull(var1);
      if (!this.aJ() && !this.ao()) {
         ListenableFutureTask<V> var2 = ListenableFutureTask.create(var1);
         synchronized(this.j) {
            this.j.add(var2);
            return var2;
         }
      } else {
         try {
            return Futures.immediateFuture(var1.call());
         } catch (Exception var6) {
            return Futures.immediateFailedCheckedFuture(var6);
         }
      }
   }

   public ListenableFuture<Object> a(Runnable var1) {
      Validate.notNull(var1);
      return this.a(Executors.callable(var1));
   }

   public boolean aJ() {
      return Thread.currentThread() == this.aa;
   }

   public int aK() {
      return 256;
   }
}
