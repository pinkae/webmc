package net.minecraft.realms;

import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;

public class RealmsAnvilLevelStorageSource {
   private .atr levelStorageSource;

   public RealmsAnvilLevelStorageSource(.atr var1) {
      this.levelStorageSource = var1;
   }

   public String getName() {
      return this.levelStorageSource.a();
   }

   public boolean levelExists(String var1) {
      return this.levelStorageSource.f(var1);
   }

   public boolean convertLevel(String var1, .nu var2) {
      return this.levelStorageSource.a(var1, var2);
   }

   public boolean requiresConversion(String var1) {
      return this.levelStorageSource.b(var1);
   }

   public boolean isNewLevelIdAcceptable(String var1) {
      return this.levelStorageSource.d(var1);
   }

   public boolean deleteLevel(String var1) {
      return this.levelStorageSource.e(var1);
   }

   public boolean isConvertible(String var1) {
      return this.levelStorageSource.a(var1);
   }

   public void renameLevel(String var1, String var2) {
      this.levelStorageSource.a(var1, var2);
   }

   public void clearAll() {
      this.levelStorageSource.d();
   }

   public List<RealmsLevelSummary> getLevelList() throws .atq {
      List<RealmsLevelSummary> var1 = Lists.newArrayList();
      Iterator var2 = this.levelStorageSource.b().iterator();

      while(var2.hasNext()) {
         .ats var3 = (.ats)var2.next();
         var1.add(new RealmsLevelSummary(var3));
      }

      return var1;
   }
}
