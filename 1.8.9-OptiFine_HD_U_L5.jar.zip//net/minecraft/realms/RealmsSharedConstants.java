package net.minecraft.realms;

public class RealmsSharedConstants {
   public static int NETWORK_PROTOCOL_VERSION = 47;
   public static int TICKS_PER_SECOND = 20;
   public static String VERSION_STRING = "1.8.9";
   public static char[] ILLEGAL_FILE_CHARACTERS;

   static {
      ILLEGAL_FILE_CHARACTERS = .f.a;
   }
}
