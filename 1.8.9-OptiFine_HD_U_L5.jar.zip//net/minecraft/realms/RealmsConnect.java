package net.minecraft.realms;

import java.net.InetAddress;
import java.net.UnknownHostException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RealmsConnect {
   private static final Logger LOGGER = LogManager.getLogger();
   private final RealmsScreen onlineScreen;
   private volatile boolean aborted = false;
   private .ek connection;

   public RealmsConnect(RealmsScreen var1) {
      this.onlineScreen = var1;
   }

   public void connect(final String var1, final int var2) {
      Realms.setConnectedToRealms(true);
      (new Thread("Realms-connect-task") {
         public void run() {
            InetAddress var1x = null;

            try {
               var1x = InetAddress.getByName(var1);
               if (RealmsConnect.this.aborted) {
                  return;
               }

               RealmsConnect.this.connection = .ek.a(var1x, var2, .ave.A().t.f());
               if (RealmsConnect.this.aborted) {
                  return;
               }

               RealmsConnect.this.connection.a((.ep)(new .bcx(RealmsConnect.this.connection, .ave.A(), RealmsConnect.this.onlineScreen.getProxy())));
               if (RealmsConnect.this.aborted) {
                  return;
               }

               RealmsConnect.this.connection.a((.ff)(new .jc(47, var1, var2, .el.d)));
               if (RealmsConnect.this.aborted) {
                  return;
               }

               RealmsConnect.this.connection.a((.ff)(new .jl(.ave.A().L().e())));
            } catch (UnknownHostException var5) {
               Realms.clearResourcePack();
               if (RealmsConnect.this.aborted) {
                  return;
               }

               RealmsConnect.LOGGER.error("Couldn't connect to world", var5);
               .ave.A().R().f();
               Realms.setScreen(new DisconnectedRealmsScreen(RealmsConnect.this.onlineScreen, "connect.failed", new .fb("disconnect.genericReason", new Object[]{"Unknown host '" + var1 + "'"})));
            } catch (Exception var6) {
               Realms.clearResourcePack();
               if (RealmsConnect.this.aborted) {
                  return;
               }

               RealmsConnect.LOGGER.error("Couldn't connect to world", var6);
               String var3 = var6.toString();
               if (var1x != null) {
                  String var4 = var1x.toString() + ":" + var2;
                  var3 = var3.replaceAll(var4, "");
               }

               Realms.setScreen(new DisconnectedRealmsScreen(RealmsConnect.this.onlineScreen, "connect.failed", new .fb("disconnect.genericReason", new Object[]{var3})));
            }

         }
      }).start();
   }

   public void abort() {
      this.aborted = true;
   }

   public void tick() {
      if (this.connection != null) {
         if (this.connection.g()) {
            this.connection.a();
         } else {
            this.connection.l();
         }
      }

   }
}
