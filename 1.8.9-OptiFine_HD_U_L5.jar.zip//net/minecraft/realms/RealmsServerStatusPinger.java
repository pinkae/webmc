package net.minecraft.realms;

import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RealmsServerStatusPinger {
   private static final Logger LOGGER = LogManager.getLogger();
   private final List<.ek> connections = Collections.synchronizedList(Lists.newArrayList());

   public void pingServer(final String var1, final RealmsServerPing var2) throws UnknownHostException {
      if (var1 != null && !var1.startsWith("0.0.0.0") && !var1.isEmpty()) {
         RealmsServerAddress var3 = RealmsServerAddress.parseString(var1);
         final .ek var4 = .ek.a(InetAddress.getByName(var3.getHost()), var3.getPort(), false);
         this.connections.add(var4);
         var4.a((.ep)(new .jp() {
            private boolean e = false;

            public void a(.jr var1x) {
               .js var2x = var1x.a();
               if (var2x.b() != null) {
                  var2.nrOfPlayers = String.valueOf(var2x.b().b());
                  if (ArrayUtils.isNotEmpty(var2x.b().c())) {
                     StringBuilder var3 = new StringBuilder();
                     GameProfile[] var4x = var2x.b().c();
                     int var5 = var4x.length;

                     for(int var6 = 0; var6 < var5; ++var6) {
                        GameProfile var7 = var4x[var6];
                        if (var3.length() > 0) {
                           var3.append("\n");
                        }

                        var3.append(var7.getName());
                     }

                     if (var2x.b().c().length < var2x.b().b()) {
                        if (var3.length() > 0) {
                           var3.append("\n");
                        }

                        var3.append("... and ").append(var2x.b().b() - var2x.b().c().length).append(" more ...");
                     }

                     var2.playerList = var3.toString();
                  }
               } else {
                  var2.playerList = "";
               }

               var4.a((.ff)(new .ju(Realms.currentTimeMillis())));
               this.e = true;
            }

            public void a(.jq var1x) {
               var4.a((.eu)(new .fa("Finished")));
            }

            public void a(.eu var1x) {
               if (!this.e) {
                  RealmsServerStatusPinger.LOGGER.error("Can't ping " + var1 + ": " + var1x.c());
               }

            }
         }));

         try {
            var4.a((.ff)(new .jc(RealmsSharedConstants.NETWORK_PROTOCOL_VERSION, var3.getHost(), var3.getPort(), .el.c)));
            var4.a((.ff)(new .jv()));
         } catch (Throwable var6) {
            LOGGER.error(var6);
         }

      }
   }

   public void tick() {
      synchronized(this.connections) {
         Iterator var2 = this.connections.iterator();

         while(var2.hasNext()) {
            .ek var3 = (.ek)var2.next();
            if (var3.g()) {
               var3.a();
            } else {
               var2.remove();
               var3.l();
            }
         }

      }
   }

   public void removeAll() {
      synchronized(this.connections) {
         Iterator var2 = this.connections.iterator();

         while(var2.hasNext()) {
            .ek var3 = (.ek)var2.next();
            if (var3.g()) {
               var2.remove();
               var3.a((.eu)(new .fa("Cancelled")));
            }
         }

      }
   }
}
