package net.minecraft.realms;

import com.google.common.util.concurrent.ListenableFuture;
import com.mojang.authlib.GameProfile;
import com.mojang.util.UUIDTypeAdapter;
import java.net.Proxy;

public class Realms {
   public static boolean isTouchScreen() {
      return .ave.A().t.A;
   }

   public static Proxy getProxy() {
      return .ave.A().O();
   }

   public static String sessionId() {
      .avm var0 = .ave.A().L();
      return var0 == null ? null : var0.a();
   }

   public static String userName() {
      .avm var0 = .ave.A().L();
      return var0 == null ? null : var0.c();
   }

   public static long currentTimeMillis() {
      return .ave.J();
   }

   public static String getSessionId() {
      return .ave.A().L().a();
   }

   public static String getUUID() {
      return .ave.A().L().b();
   }

   public static String getName() {
      return .ave.A().L().c();
   }

   public static String uuidToName(String var0) {
      return .ave.A().aa().fillProfileProperties(new GameProfile(UUIDTypeAdapter.fromString(var0), (String)null), false).getName();
   }

   public static void setScreen(RealmsScreen var0) {
      .ave.A().a((.axu)var0.getProxy());
   }

   public static String getGameDirectoryPath() {
      return .ave.A().v.getAbsolutePath();
   }

   public static int survivalId() {
      return .adp.a.b.a();
   }

   public static int creativeId() {
      return .adp.a.c.a();
   }

   public static int adventureId() {
      return .adp.a.d.a();
   }

   public static int spectatorId() {
      return .adp.a.e.a();
   }

   public static void setConnectedToRealms(boolean var0) {
      .ave.A().a(var0);
   }

   public static ListenableFuture<Object> downloadResourcePack(String var0, String var1) {
      ListenableFuture<Object> var2 = .ave.A().R().a(var0, var1);
      return var2;
   }

   public static void clearResourcePack() {
      .ave.A().R().f();
   }

   public static boolean getRealmsNotificationsEnabled() {
      return .ave.A().t.b(.avh.a.S);
   }

   public static boolean inTitleScreen() {
      return .ave.A().m != null && .ave.A().m instanceof .aya;
   }
}
