public class aie extends afh {
   public aie() {
      super(arm.e);
      this.a(yz.b);
   }

   public arn g(alz var1) {
      return arn.K;
   }
}
