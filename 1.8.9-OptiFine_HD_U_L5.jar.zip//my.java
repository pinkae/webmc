public class my {
   private int a;
   private mz b;

   public int a() {
      return this.a;
   }

   public void a(int var1) {
      this.a = var1;
   }

   public <T extends mz> T b() {
      return this.b;
   }

   public void a(mz var1) {
      this.b = var1;
   }
}
