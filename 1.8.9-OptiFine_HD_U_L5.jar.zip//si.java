public class si extends rd {
   private wi a;

   public si(wi var1) {
      this.a = var1;
      this.a(5);
   }

   public boolean a() {
      if (!this.a.ai()) {
         return false;
      } else if (this.a.V()) {
         return false;
      } else if (!this.a.C) {
         return false;
      } else if (this.a.G) {
         return false;
      } else {
         wn var1 = this.a.v_();
         if (var1 == null) {
            return false;
         } else if (this.a.h(var1) > 16.0D) {
            return false;
         } else {
            return var1.bk instanceof xi;
         }
      }
   }

   public void c() {
      this.a.s().n();
   }

   public void d() {
      this.a.a_((wn)null);
   }
}
