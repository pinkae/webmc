public class yr extends zw {
   public boolean f_(zx var1) {
      return var1.b == 1;
   }

   public int b() {
      return 1;
   }
}
