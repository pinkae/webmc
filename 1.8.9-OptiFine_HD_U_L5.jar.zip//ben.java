public class ben extends beo {
   protected ben(adm var1, double var2, double var4, double var6, double var8, double var10, double var12, alz var14) {
      super(var1, var2, var4, var6, var8, var10, var12, var14);
      this.v = var8;
      this.w = var10;
      this.x = var12;
   }

   public static class a implements bed {
      public beb a(int var1, adm var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
         alz var16 = afh.d(var15[0]);
         return var16.c().b() == -1 ? null : (new ben(var2, var3, var5, var7, var9, var11, var13, var16)).l();
      }
   }
}
