public class ajq extends afh {
   public ajq() {
      super(arm.p, arn.B);
      this.a(yz.b);
   }

   public aug a(adm var1, cj var2, alz var3) {
      float var4 = 0.125F;
      return new aug((double)var2.n(), (double)var2.o(), (double)var2.p(), (double)(var2.n() + 1), (double)((float)(var2.o() + 1) - var4), (double)(var2.p() + 1));
   }

   public void a(adm var1, cj var2, alz var3, pk var4) {
      var4.v *= 0.4D;
      var4.x *= 0.4D;
   }
}
