public enum aaj {
   a(a.p, "Common"),
   b(a.o, "Uncommon"),
   c(a.l, "Rare"),
   d(a.n, "Epic");

   public final a e;
   public final String f;

   private aaj(a var3, String var4) {
      this.e = var3;
      this.f = var4;
   }
}
