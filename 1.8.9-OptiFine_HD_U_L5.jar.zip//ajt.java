import java.util.List;

public class ajt extends akd {
   public static final amm<zd> a = amm.a("color", zd.class);

   public ajt() {
      super(arm.s, false);
      this.j(this.M.b().a(b, false).a(N, false).a(O, false).a(P, false).a(a, zd.a));
      this.a(yz.c);
   }

   public int a(alz var1) {
      return ((zd)var1.b(a)).a();
   }

   public void a(zw var1, yz var2, List<zx> var3) {
      for(int var4 = 0; var4 < zd.values().length; ++var4) {
         var3.add(new zx(var1, 1, var4));
      }

   }

   public arn g(alz var1) {
      return ((zd)var1.b(a)).e();
   }

   public adf m() {
      return adf.d;
   }

   public alz a(int var1) {
      return this.Q().a(a, zd.b(var1));
   }

   public int c(alz var1) {
      return ((zd)var1.b(a)).a();
   }

   protected ama e() {
      return new ama(this, new amo[]{b, N, P, O, a});
   }

   public void c(adm var1, cj var2, alz var3) {
      if (!var1.D) {
         aff.f(var1, var2);
      }

   }

   public void b(adm var1, cj var2, alz var3) {
      if (!var1.D) {
         aff.f(var1, var2);
      }

   }
}
