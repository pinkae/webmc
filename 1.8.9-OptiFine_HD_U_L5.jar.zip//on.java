public class on {
   public static final on a = new on("");
   private final String b;

   public on(String var1) {
      this.b = var1;
   }

   public boolean a() {
      return this.b == null || this.b.isEmpty();
   }

   public String b() {
      return this.b;
   }

   public void a(dn var1) {
      var1.a("Lock", this.b);
   }

   public static on b(dn var0) {
      if (var0.b("Lock", 8)) {
         String var1 = var0.j("Lock");
         return new on(var1);
      } else {
         return a;
      }
   }
}
