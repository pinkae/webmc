public class bij extends bjo<vl> {
   private static final jy a = new jy("textures/entity/blaze.png");

   public bij(biu var1) {
      super(var1, new baw(), 0.5F);
   }

   protected jy a(vl var1) {
      return a;
   }
}
