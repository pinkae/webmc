public abstract class tz extends ps implements pi {
   public tz(adm var1) {
      super(var1);
   }

   public boolean aY() {
      return true;
   }

   public boolean bR() {
      return true;
   }

   public boolean bS() {
      return this.o.a((aug)this.aR(), (pk)this);
   }

   public int w() {
      return 120;
   }

   protected boolean C() {
      return true;
   }

   protected int b(wn var1) {
      return 1 + this.o.s.nextInt(3);
   }

   public void K() {
      int var1 = this.az();
      super.K();
      if (this.ai() && !this.V()) {
         --var1;
         this.h(var1);
         if (this.az() == -20) {
            this.h(0);
            this.a(ow.f, 2.0F);
         }
      } else {
         this.h(300);
      }

   }

   public boolean aL() {
      return false;
   }
}
