import com.google.common.base.Objects;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.mojang.authlib.minecraft.MinecraftProfileTexture.Type;

public class bdc {
   private final GameProfile a;
   private adp.a b;
   private int c;
   private boolean d = false;
   private jy e;
   private jy f;
   private String g;
   private eu h;
   private int i = 0;
   private int j = 0;
   private long k = 0L;
   private long l = 0L;
   private long m = 0L;

   public bdc(GameProfile var1) {
      this.a = var1;
   }

   public bdc(gz.b var1) {
      this.a = var1.a();
      this.b = var1.c();
      this.c = var1.b();
      this.h = var1.d();
   }

   public GameProfile a() {
      return this.a;
   }

   public adp.a b() {
      return this.b;
   }

   public int c() {
      return this.c;
   }

   protected void a(adp.a var1) {
      this.b = var1;
   }

   protected void a(int var1) {
      this.c = var1;
   }

   public boolean e() {
      return this.e != null;
   }

   public String f() {
      return this.g == null ? bmz.b(this.a.getId()) : this.g;
   }

   public jy g() {
      if (this.e == null) {
         this.j();
      }

      return (jy)Objects.firstNonNull(this.e, bmz.a(this.a.getId()));
   }

   public jy h() {
      if (this.f == null) {
         this.j();
      }

      return this.f;
   }

   public aul i() {
      return ave.A().f.Z().h(this.a().getName());
   }

   protected void j() {
      synchronized(this) {
         if (!this.d) {
            this.d = true;
            ave.A().ab().a(this.a, new bnp.a() {
               public void a(Type var1, jy var2, MinecraftProfileTexture var3) {
                  switch(var1) {
                  case SKIN:
                     bdc.this.e = var2;
                     bdc.this.g = var3.getMetadata("model");
                     if (bdc.this.g == null) {
                        bdc.this.g = "default";
                     }
                     break;
                  case CAPE:
                     bdc.this.f = var2;
                  }

               }
            }, true);
         }

      }
   }

   public void a(eu var1) {
      this.h = var1;
   }

   public eu k() {
      return this.h;
   }

   public int l() {
      return this.i;
   }

   public void b(int var1) {
      this.i = var1;
   }

   public int m() {
      return this.j;
   }

   public void c(int var1) {
      this.j = var1;
   }

   public long n() {
      return this.k;
   }

   public void a(long var1) {
      this.k = var1;
   }

   public long o() {
      return this.l;
   }

   public void b(long var1) {
      this.l = var1;
   }

   public long p() {
      return this.m;
   }

   public void c(long var1) {
      this.m = var1;
   }
}
