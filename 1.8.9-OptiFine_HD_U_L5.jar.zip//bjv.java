public class bjv extends bjo<tv> {
   private static final jy a = new jy("textures/entity/sheep/sheep.png");

   public bjv(biu var1, bbo var2, float var3) {
      super(var1, var2, var3);
      this.a((blb)(new blc(this)));
   }

   protected jy a(tv var1) {
      return a;
   }
}
