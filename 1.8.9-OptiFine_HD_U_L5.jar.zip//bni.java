import java.io.IOException;
import java.util.List;
import java.util.Set;

public interface bni {
   Set<String> a();

   bnh a(jy var1) throws IOException;

   List<bnh> b(jy var1) throws IOException;
}
