public class atl extends ato {
   private final ato b;

   public atl(ato var1) {
      this.b = var1;
   }

   public dn a() {
      return this.b.a();
   }

   public dn a(dn var1) {
      return this.b.a(var1);
   }

   public long b() {
      return this.b.b();
   }

   public int c() {
      return this.b.c();
   }

   public int d() {
      return this.b.d();
   }

   public int e() {
      return this.b.e();
   }

   public long f() {
      return this.b.f();
   }

   public long g() {
      return this.b.g();
   }

   public long h() {
      return this.b.h();
   }

   public dn i() {
      return this.b.i();
   }

   public String k() {
      return this.b.k();
   }

   public int l() {
      return this.b.l();
   }

   public long m() {
      return this.b.m();
   }

   public boolean n() {
      return this.b.n();
   }

   public int o() {
      return this.b.o();
   }

   public boolean p() {
      return this.b.p();
   }

   public int q() {
      return this.b.q();
   }

   public adp.a r() {
      return this.b.r();
   }

   public void a(int var1) {
   }

   public void b(int var1) {
   }

   public void c(int var1) {
   }

   public void b(long var1) {
   }

   public void c(long var1) {
   }

   public void a(cj var1) {
   }

   public void a(String var1) {
   }

   public void e(int var1) {
   }

   public void a(boolean var1) {
   }

   public void f(int var1) {
   }

   public void b(boolean var1) {
   }

   public void g(int var1) {
   }

   public boolean s() {
      return this.b.s();
   }

   public boolean t() {
      return this.b.t();
   }

   public adr u() {
      return this.b.u();
   }

   public void a(adr var1) {
   }

   public boolean v() {
      return this.b.v();
   }

   public void c(boolean var1) {
   }

   public boolean w() {
      return this.b.w();
   }

   public void d(boolean var1) {
   }

   public adk x() {
      return this.b.x();
   }

   public oj y() {
      return this.b.y();
   }

   public void a(oj var1) {
   }

   public boolean z() {
      return this.b.z();
   }

   public void e(boolean var1) {
   }
}
