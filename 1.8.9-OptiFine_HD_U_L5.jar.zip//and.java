import java.io.IOException;

public interface and {
   amy a(adm var1, int var2, int var3) throws IOException;

   void a(adm var1, amy var2) throws IOException, adn;

   void b(adm var1, amy var2) throws IOException;

   void a();

   void b();
}
