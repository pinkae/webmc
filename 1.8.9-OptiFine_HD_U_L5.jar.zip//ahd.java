import java.util.Random;

public class ahd extends afh {
   public ahd(arm var1) {
      super(var1);
      this.a(yz.b);
   }

   public int a(int var1, Random var2) {
      return ns.a(this.a(var2) + var2.nextInt(var1 + 1), 1, 4);
   }

   public int a(Random var1) {
      return 2 + var1.nextInt(3);
   }

   public zw a(alz var1, Random var2, int var3) {
      return zy.aT;
   }

   public arn g(alz var1) {
      return arn.d;
   }
}
