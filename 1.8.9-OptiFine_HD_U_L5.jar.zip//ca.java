public class ca extends bz {
   public ca() {
      this("commands.generic.entity.notFound");
   }

   public ca(String var1, Object... var2) {
      super(var1, var2);
   }
}
