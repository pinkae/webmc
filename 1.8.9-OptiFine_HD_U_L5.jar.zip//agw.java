import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import java.util.Collection;
import java.util.List;

public abstract class agw extends afm {
   protected amm<agw.a> a;

   protected agw() {
      this.j(this.M.b().a(this.n(), this.l() == agw.b.b ? agw.a.b : agw.a.a));
   }

   public int a(alz var1) {
      return ((agw.a)var1.b(this.n())).b();
   }

   public void a(zw var1, yz var2, List<zx> var3) {
      agw.a[] var4 = agw.a.a(this.l());
      int var5 = var4.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         agw.a var7 = var4[var6];
         var3.add(new zx(var1, 1, var7.b()));
      }

   }

   public alz a(int var1) {
      return this.Q().a(this.n(), agw.a.a(this.l(), var1));
   }

   public abstract agw.b l();

   public amo<agw.a> n() {
      if (this.a == null) {
         this.a = amm.a("type", agw.a.class, new Predicate<agw.a>() {
            public boolean a(agw.a var1) {
               return var1.a() == agw.this.l();
            }

            // $FF: synthetic method
            public boolean apply(Object var1) {
               return this.a((agw.a)var1);
            }
         });
      }

      return this.a;
   }

   public int c(alz var1) {
      return ((agw.a)var1.b(this.n())).b();
   }

   protected ama e() {
      return new ama(this, new amo[]{this.n()});
   }

   public afh.a R() {
      return afh.a.b;
   }

   public static enum a implements nw {
      a(agw.b.a, 0, "dandelion"),
      b(agw.b.b, 0, "poppy"),
      c(agw.b.b, 1, "blue_orchid", "blueOrchid"),
      d(agw.b.b, 2, "allium"),
      e(agw.b.b, 3, "houstonia"),
      f(agw.b.b, 4, "red_tulip", "tulipRed"),
      g(agw.b.b, 5, "orange_tulip", "tulipOrange"),
      h(agw.b.b, 6, "white_tulip", "tulipWhite"),
      i(agw.b.b, 7, "pink_tulip", "tulipPink"),
      j(agw.b.b, 8, "oxeye_daisy", "oxeyeDaisy");

      private static final agw.a[][] k = new agw.a[agw.b.values().length][];
      private final agw.b l;
      private final int m;
      private final String n;
      private final String o;

      private a(agw.b var3, int var4, String var5) {
         this(var3, var4, var5, var5);
      }

      private a(agw.b var3, int var4, String var5, String var6) {
         this.l = var3;
         this.m = var4;
         this.n = var5;
         this.o = var6;
      }

      public agw.b a() {
         return this.l;
      }

      public int b() {
         return this.m;
      }

      public static agw.a a(agw.b var0, int var1) {
         agw.a[] var2 = k[var0.ordinal()];
         if (var1 < 0 || var1 >= var2.length) {
            var1 = 0;
         }

         return var2[var1];
      }

      public static agw.a[] a(agw.b var0) {
         return k[var0.ordinal()];
      }

      public String toString() {
         return this.n;
      }

      public String l() {
         return this.n;
      }

      public String d() {
         return this.o;
      }

      static {
         agw.b[] var0 = agw.b.values();
         int var1 = var0.length;

         for(int var2 = 0; var2 < var1; ++var2) {
            final agw.b var3 = var0[var2];
            Collection<agw.a> var4 = Collections2.filter(Lists.newArrayList(values()), new Predicate<agw.a>() {
               public boolean a(agw.a var1) {
                  return var1.a() == var3;
               }

               // $FF: synthetic method
               public boolean apply(Object var1) {
                  return this.a((agw.a)var1);
               }
            });
            k[var3.ordinal()] = (agw.a[])var4.toArray(new agw.a[var4.size()]);
         }

      }
   }

   public static enum b {
      a,
      b;

      public agw a() {
         return this == a ? afi.N : afi.O;
      }
   }
}
