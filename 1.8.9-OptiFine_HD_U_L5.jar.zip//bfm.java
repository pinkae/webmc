import java.awt.image.BufferedImage;

public interface bfm {
   BufferedImage a(BufferedImage var1);

   void a();
}
