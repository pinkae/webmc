public class bey implements ol {
   private String a;
   private eu b;

   public bey(String var1, eu var2) {
      this.a = var1;
      this.b = var2;
   }

   public xi a(wm var1, wn var2) {
      throw new UnsupportedOperationException();
   }

   public String e_() {
      return this.b.c();
   }

   public boolean l_() {
      return true;
   }

   public String k() {
      return this.a;
   }

   public eu f_() {
      return this.b;
   }
}
