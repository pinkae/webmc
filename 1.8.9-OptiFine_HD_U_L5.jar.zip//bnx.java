import com.google.gson.JsonDeserializer;

public interface bnx<T extends bnw> extends JsonDeserializer<T> {
   String a();
}
