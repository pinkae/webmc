public class cl implements ck {
   private final adm a;
   private final cj b;

   public cl(adm var1, cj var2) {
      this.a = var1;
      this.b = var2;
   }

   public adm i() {
      return this.a;
   }

   public double a() {
      return (double)this.b.n() + 0.5D;
   }

   public double b() {
      return (double)this.b.o() + 0.5D;
   }

   public double c() {
      return (double)this.b.p() + 0.5D;
   }

   public cj d() {
      return this.b;
   }

   public int f() {
      alz var1 = this.a.p(this.b);
      return var1.c().c(var1);
   }

   public <T extends akw> T h() {
      return this.a.s(this.b);
   }
}
