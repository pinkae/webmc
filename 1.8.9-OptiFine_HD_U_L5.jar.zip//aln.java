import com.google.gson.JsonParseException;
import net.minecraft.server.MinecraftServer;

public class aln extends akw {
   public final eu[] a = new eu[]{new fa(""), new fa(""), new fa(""), new fa("")};
   public int f = -1;
   private boolean g = true;
   private wn h;
   private final n i = new n();

   public void b(dn var1) {
      super.b(var1);

      for(int var2 = 0; var2 < 4; ++var2) {
         String var3 = eu.a.a(this.a[var2]);
         var1.a("Text" + (var2 + 1), var3);
      }

      this.i.b(var1);
   }

   public void a(dn var1) {
      this.g = false;
      super.a(var1);
      m var2 = new m() {
         public String e_() {
            return "Sign";
         }

         public eu f_() {
            return new fa(this.e_());
         }

         public void a(eu var1) {
         }

         public boolean a(int var1, String var2) {
            return true;
         }

         public cj c() {
            return aln.this.c;
         }

         public aui d() {
            return new aui((double)aln.this.c.n() + 0.5D, (double)aln.this.c.o() + 0.5D, (double)aln.this.c.p() + 0.5D);
         }

         public adm e() {
            return aln.this.b;
         }

         public pk f() {
            return null;
         }

         public boolean u_() {
            return false;
         }

         public void a(n.a var1, int var2) {
         }
      };

      for(int var3 = 0; var3 < 4; ++var3) {
         String var4 = var1.j("Text" + (var3 + 1));

         try {
            eu var5 = eu.a.a(var4);

            try {
               this.a[var3] = ev.a(var2, var5, (pk)null);
            } catch (bz var7) {
               this.a[var3] = var5;
            }
         } catch (JsonParseException var8) {
            this.a[var3] = new fa(var4);
         }
      }

      this.i.a(var1);
   }

   public ff y_() {
      eu[] var1 = new eu[4];
      System.arraycopy(this.a, 0, var1, 0, 4);
      return new hw(this.b, this.c, var1);
   }

   public boolean F() {
      return true;
   }

   public boolean b() {
      return this.g;
   }

   public void a(boolean var1) {
      this.g = var1;
      if (!var1) {
         this.h = null;
      }

   }

   public void a(wn var1) {
      this.h = var1;
   }

   public wn c() {
      return this.h;
   }

   public boolean b(final wn var1) {
      m var2 = new m() {
         public String e_() {
            return var1.e_();
         }

         public eu f_() {
            return var1.f_();
         }

         public void a(eu var1x) {
         }

         public boolean a(int var1x, String var2) {
            return var1x <= 2;
         }

         public cj c() {
            return aln.this.c;
         }

         public aui d() {
            return new aui((double)aln.this.c.n() + 0.5D, (double)aln.this.c.o() + 0.5D, (double)aln.this.c.p() + 0.5D);
         }

         public adm e() {
            return var1.e();
         }

         public pk f() {
            return var1;
         }

         public boolean u_() {
            return false;
         }

         public void a(n.a var1x, int var2) {
            aln.this.i.a(this, var1x, var2);
         }
      };

      for(int var3 = 0; var3 < this.a.length; ++var3) {
         ez var4 = this.a[var3] == null ? null : this.a[var3].b();
         if (var4 != null && var4.h() != null) {
            et var5 = var4.h();
            if (var5.a() == et.a.c) {
               MinecraftServer.N().P().a(var2, var5.b());
            }
         }
      }

      return true;
   }

   public n d() {
      return this.i;
   }
}
