import java.io.IOException;

public class iy implements ff<ic> {
   public void a(em var1) throws IOException {
   }

   public void b(em var1) throws IOException {
   }

   public void a(ic var1) {
      var1.a(this);
   }
}
