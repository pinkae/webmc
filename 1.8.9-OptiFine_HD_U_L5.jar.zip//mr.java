import com.google.common.collect.Lists;
import java.util.List;

public class mr {
   public static int a;
   public static int b;
   public static int c;
   public static int d;
   public static List<mq> e = Lists.newArrayList();
   public static mq f;
   public static mq g;
   public static mq h;
   public static mq i;
   public static mq j;
   public static mq k;
   public static mq l;
   public static mq m;
   public static mq n;
   public static mq o;
   public static mq p;
   public static mq q;
   public static mq r;
   public static mq s;
   public static mq t;
   public static mq u;
   public static mq v;
   public static mq w;
   public static mq x;
   public static mq y;
   public static mq z;
   public static mq A;
   public static mq B;
   public static mq C;
   public static mq D;
   public static mq E;
   public static mq F;
   public static mq G;
   public static mq H;
   public static mq I;
   public static mq J;
   public static mq K;
   public static mq L;
   public static mq M;

   public static void a() {
   }

   static {
      f = (new mq("achievement.openInventory", "openInventory", 0, 0, zy.aL, (mq)null)).a().c();
      g = (new mq("achievement.mineWood", "mineWood", 2, 1, afi.r, f)).c();
      h = (new mq("achievement.buildWorkBench", "buildWorkBench", 4, -1, afi.ai, g)).c();
      i = (new mq("achievement.buildPickaxe", "buildPickaxe", 4, 2, zy.o, h)).c();
      j = (new mq("achievement.buildFurnace", "buildFurnace", 3, 4, afi.al, i)).c();
      k = (new mq("achievement.acquireIron", "acquireIron", 1, 4, zy.j, j)).c();
      l = (new mq("achievement.buildHoe", "buildHoe", 2, -3, zy.I, h)).c();
      m = (new mq("achievement.makeBread", "makeBread", -1, -3, zy.P, l)).c();
      n = (new mq("achievement.bakeCake", "bakeCake", 0, -5, zy.aZ, l)).c();
      o = (new mq("achievement.buildBetterPickaxe", "buildBetterPickaxe", 6, 2, zy.s, i)).c();
      p = (new mq("achievement.cookFish", "cookFish", 2, 6, zy.aV, j)).c();
      q = (new mq("achievement.onARail", "onARail", 2, 3, afi.av, k)).b().c();
      r = (new mq("achievement.buildSword", "buildSword", 6, -1, zy.m, h)).c();
      s = (new mq("achievement.killEnemy", "killEnemy", 8, -1, zy.aX, r)).c();
      t = (new mq("achievement.killCow", "killCow", 7, -3, zy.aF, r)).c();
      u = (new mq("achievement.flyPig", "flyPig", 9, -3, zy.aA, t)).b().c();
      v = (new mq("achievement.snipeSkeleton", "snipeSkeleton", 7, 0, zy.f, s)).b().c();
      w = (new mq("achievement.diamonds", "diamonds", -1, 5, afi.ag, k)).c();
      x = (new mq("achievement.diamondsToYou", "diamondsToYou", -1, 2, zy.i, w)).c();
      y = (new mq("achievement.portal", "portal", -1, 7, afi.Z, w)).c();
      z = (new mq("achievement.ghast", "ghast", -4, 8, zy.bw, y)).b().c();
      A = (new mq("achievement.blazeRod", "blazeRod", 0, 9, zy.bv, y)).c();
      B = (new mq("achievement.potion", "potion", 2, 8, zy.bz, A)).c();
      C = (new mq("achievement.theEnd", "theEnd", 3, 10, zy.bH, A)).b().c();
      D = (new mq("achievement.theEnd2", "theEnd2", 4, 13, afi.bI, C)).b().c();
      E = (new mq("achievement.enchantments", "enchantments", -4, 4, afi.bC, w)).c();
      F = (new mq("achievement.overkill", "overkill", -4, 1, zy.u, E)).b().c();
      G = (new mq("achievement.bookcase", "bookcase", -3, 6, afi.X, E)).c();
      H = (new mq("achievement.breedCow", "breedCow", 7, -5, zy.O, t)).c();
      I = (new mq("achievement.spawnWither", "spawnWither", 7, 12, new zx(zy.bX, 1, 1), D)).c();
      J = (new mq("achievement.killWither", "killWither", 7, 10, zy.bZ, I)).c();
      K = (new mq("achievement.fullBeacon", "fullBeacon", 7, 8, afi.bY, J)).b().c();
      L = (new mq("achievement.exploreAllBiomes", "exploreAllBiomes", 4, 8, zy.af, C)).a(nc.class).b().c();
      M = (new mq("achievement.overpowered", "overpowered", 6, 4, new zx(zy.ao, 1, 1), o)).b().c();
   }
}
