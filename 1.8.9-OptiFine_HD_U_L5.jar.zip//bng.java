import java.util.List;

public interface bng extends bni {
   void a(List<bnk> var1);

   void a(bnj var1);
}
