public class all extends akw implements km {
   private final add a = new add() {
      public void a(int var1) {
         all.this.b.c(all.this.c, afi.ac, var1, 0);
      }

      public adm a() {
         return all.this.b;
      }

      public cj b() {
         return all.this.c;
      }

      public void a(add.a var1) {
         super.a(var1);
         if (this.a() != null) {
            this.a().h(all.this.c);
         }

      }
   };

   public void a(dn var1) {
      super.a(var1);
      this.a.a(var1);
   }

   public void b(dn var1) {
      super.b(var1);
      this.a.b(var1);
   }

   public void c() {
      this.a.c();
   }

   public ff y_() {
      dn var1 = new dn();
      this.b(var1);
      var1.o("SpawnPotentials");
      return new ft(this.c, 1, var1);
   }

   public boolean c(int var1, int var2) {
      return this.a.b(var1) ? true : super.c(var1, var2);
   }

   public boolean F() {
      return true;
   }

   public add b() {
      return this.a;
   }
}
