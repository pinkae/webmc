public interface amq {
   void a(ams var1, double var2);

   void a(ams var1, double var2, double var4, long var6);

   void a(ams var1, double var2, double var4);

   void a(ams var1, int var2);

   void b(ams var1, int var2);

   void b(ams var1, double var2);

   void c(ams var1, double var2);
}
