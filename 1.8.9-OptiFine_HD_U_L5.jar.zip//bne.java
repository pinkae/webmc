import java.io.IOException;

public class bne implements bnj {
   private static final jy a = new jy("textures/colormap/foliage.png");

   public void a(bni var1) {
      try {
         adj.a(bml.a(var1, a));
      } catch (IOException var3) {
      }

   }
}
