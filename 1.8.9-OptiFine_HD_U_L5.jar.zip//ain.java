import java.util.Random;

public class ain extends afh {
   public ain() {
      super(arm.x);
      this.L = 0.98F;
      this.a(yz.b);
   }

   public int a(Random var1) {
      return 0;
   }
}
