import com.google.common.base.Predicate;
import java.util.List;
import java.util.Random;

public class amx extends amy {
   public amx(adm var1, int var2, int var3) {
      super(var1, var2, var3);
   }

   public boolean a(int var1, int var2) {
      return var1 == this.a && var2 == this.b;
   }

   public int b(int var1, int var2) {
      return 0;
   }

   public void a() {
   }

   public void b() {
   }

   public afh a(cj var1) {
      return afi.a;
   }

   public int b(cj var1) {
      return 255;
   }

   public int c(cj var1) {
      return 0;
   }

   public int a(ads var1, cj var2) {
      return var1.c;
   }

   public void a(ads var1, cj var2, int var3) {
   }

   public int a(cj var1, int var2) {
      return 0;
   }

   public void a(pk var1) {
   }

   public void b(pk var1) {
   }

   public void a(pk var1, int var2) {
   }

   public boolean d(cj var1) {
      return false;
   }

   public akw a(cj var1, amy.a var2) {
      return null;
   }

   public void a(akw var1) {
   }

   public void a(cj var1, akw var2) {
   }

   public void e(cj var1) {
   }

   public void c() {
   }

   public void d() {
   }

   public void e() {
   }

   public void a(pk var1, aug var2, List<pk> var3, Predicate<? super pk> var4) {
   }

   public <T extends pk> void a(Class<? extends T> var1, aug var2, List<T> var3, Predicate<? super T> var4) {
   }

   public boolean a(boolean var1) {
      return false;
   }

   public Random a(long var1) {
      return new Random(this.p().J() + (long)(this.a * this.a * 4987142) + (long)(this.a * 5947611) + (long)(this.b * this.b) * 4392871L + (long)(this.b * 389711) ^ var1);
   }

   public boolean f() {
      return true;
   }

   public boolean c(int var1, int var2) {
      return true;
   }
}
