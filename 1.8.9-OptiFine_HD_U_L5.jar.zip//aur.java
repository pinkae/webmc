import java.util.List;

public class aur implements auu {
   private final String j;

   public aur(String var1, .a var2) {
      this.j = var1 + var2.e();
      auu.a.put(this.j, this);
   }

   public String a() {
      return this.j;
   }

   public int a(List<wn> var1) {
      return 0;
   }

   public boolean b() {
      return false;
   }

   public auu.a c() {
      return auu.a.a;
   }
}
