public interface bah {
   void a(baf var1);

   eu A_();

   void a(float var1, int var2);

   boolean B_();
}
