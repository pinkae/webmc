import com.google.common.collect.Queues;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelException;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.epoll.Epoll;
import io.netty.channel.epoll.EpollEventLoopGroup;
import io.netty.channel.epoll.EpollSocketChannel;
import io.netty.channel.local.LocalChannel;
import io.netty.channel.local.LocalEventLoopGroup;
import io.netty.channel.local.LocalServerChannel;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.TimeoutException;
import io.netty.util.AttributeKey;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import java.net.InetAddress;
import java.net.SocketAddress;
import java.util.Queue;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import javax.crypto.SecretKey;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;

public class ek extends SimpleChannelInboundHandler<ff> {
   private static final Logger g = LogManager.getLogger();
   public static final Marker a = MarkerManager.getMarker("NETWORK");
   public static final Marker b;
   public static final AttributeKey<el> c;
   public static final no<NioEventLoopGroup> d;
   public static final no<EpollEventLoopGroup> e;
   public static final no<LocalEventLoopGroup> f;
   private final fg h;
   private final Queue<ek.a> i = Queues.newConcurrentLinkedQueue();
   private final ReentrantReadWriteLock j = new ReentrantReadWriteLock();
   private Channel k;
   private SocketAddress l;
   private ep m;
   private eu n;
   private boolean o;
   private boolean p;

   public ek(fg var1) {
      this.h = var1;
   }

   public void channelActive(ChannelHandlerContext var1) throws Exception {
      super.channelActive(var1);
      this.k = var1.channel();
      this.l = this.k.remoteAddress();

      try {
         this.a(el.a);
      } catch (Throwable var3) {
         g.fatal(var3);
      }

   }

   public void a(el var1) {
      this.k.attr(c).set(var1);
      this.k.config().setAutoRead(true);
      g.debug("Enabled auto read");
   }

   public void channelInactive(ChannelHandlerContext var1) throws Exception {
      this.a((eu)(new fb("disconnect.endOfStream", new Object[0])));
   }

   public void exceptionCaught(ChannelHandlerContext var1, Throwable var2) throws Exception {
      fb var3;
      if (var2 instanceof TimeoutException) {
         var3 = new fb("disconnect.timeout", new Object[0]);
      } else {
         var3 = new fb("disconnect.genericReason", new Object[]{"Internal Exception: " + var2});
      }

      this.a((eu)var3);
   }

   protected void a(ChannelHandlerContext var1, ff var2) throws Exception {
      if (this.k.isOpen()) {
         try {
            var2.a(this.m);
         } catch (ki var4) {
         }
      }

   }

   public void a(ep var1) {
      Validate.notNull(var1, "packetListener", new Object[0]);
      g.debug("Set listener of {} to {}", new Object[]{this, var1});
      this.m = var1;
   }

   public void a(ff var1) {
      if (this.g()) {
         this.m();
         this.a((ff)var1, (GenericFutureListener[])null);
      } else {
         this.j.writeLock().lock();

         try {
            this.i.add(new ek.a(var1, (GenericFutureListener[])null));
         } finally {
            this.j.writeLock().unlock();
         }
      }

   }

   public void a(ff var1, GenericFutureListener<? extends Future<? super Void>> var2, GenericFutureListener<? extends Future<? super Void>>... var3) {
      if (this.g()) {
         this.m();
         this.a(var1, (GenericFutureListener[])ArrayUtils.add(var3, 0, var2));
      } else {
         this.j.writeLock().lock();

         try {
            this.i.add(new ek.a(var1, (GenericFutureListener[])ArrayUtils.add(var3, 0, var2)));
         } finally {
            this.j.writeLock().unlock();
         }
      }

   }

   private void a(final ff var1, final GenericFutureListener<? extends Future<? super Void>>[] var2) {
      final el var3 = el.a(var1);
      final el var4 = (el)this.k.attr(c).get();
      if (var4 != var3) {
         g.debug("Disabled auto read");
         this.k.config().setAutoRead(false);
      }

      if (this.k.eventLoop().inEventLoop()) {
         if (var3 != var4) {
            this.a(var3);
         }

         ChannelFuture var5 = this.k.writeAndFlush(var1);
         if (var2 != null) {
            var5.addListeners(var2);
         }

         var5.addListener(ChannelFutureListener.FIRE_EXCEPTION_ON_FAILURE);
      } else {
         this.k.eventLoop().execute(new Runnable() {
            public void run() {
               if (var3 != var4) {
                  ek.this.a(var3);
               }

               ChannelFuture var1x = ek.this.k.writeAndFlush(var1);
               if (var2 != null) {
                  var1x.addListeners(var2);
               }

               var1x.addListener(ChannelFutureListener.FIRE_EXCEPTION_ON_FAILURE);
            }
         });
      }

   }

   private void m() {
      if (this.k != null && this.k.isOpen()) {
         this.j.readLock().lock();

         try {
            while(!this.i.isEmpty()) {
               ek.a var1 = (ek.a)this.i.poll();
               this.a(var1.a, var1.b);
            }
         } finally {
            this.j.readLock().unlock();
         }

      }
   }

   public void a() {
      this.m();
      if (this.m instanceof km) {
         ((km)this.m).c();
      }

      this.k.flush();
   }

   public SocketAddress b() {
      return this.l;
   }

   public void a(eu var1) {
      if (this.k.isOpen()) {
         this.k.close().awaitUninterruptibly();
         this.n = var1;
      }

   }

   public boolean c() {
      return this.k instanceof LocalChannel || this.k instanceof LocalServerChannel;
   }

   public static ek a(InetAddress var0, int var1, boolean var2) {
      final ek var3 = new ek(fg.b);
      Class var4;
      no var5;
      if (Epoll.isAvailable() && var2) {
         var4 = EpollSocketChannel.class;
         var5 = e;
      } else {
         var4 = NioSocketChannel.class;
         var5 = d;
      }

      ((Bootstrap)((Bootstrap)((Bootstrap)(new Bootstrap()).group((EventLoopGroup)var5.c())).handler(new ChannelInitializer<Channel>() {
         protected void initChannel(Channel var1) throws Exception {
            try {
               var1.config().setOption(ChannelOption.TCP_NODELAY, true);
            } catch (ChannelException var3x) {
            }

            var1.pipeline().addLast("timeout", new ReadTimeoutHandler(30)).addLast("splitter", new eq()).addLast("decoder", new en(fg.b)).addLast("prepender", new er()).addLast("encoder", new eo(fg.a)).addLast("packet_handler", var3);
         }
      })).channel(var4)).connect(var0, var1).syncUninterruptibly();
      return var3;
   }

   public static ek a(SocketAddress var0) {
      final ek var1 = new ek(fg.b);
      ((Bootstrap)((Bootstrap)((Bootstrap)(new Bootstrap()).group((EventLoopGroup)f.c())).handler(new ChannelInitializer<Channel>() {
         protected void initChannel(Channel var1x) throws Exception {
            var1x.pipeline().addLast("packet_handler", var1);
         }
      })).channel(LocalChannel.class)).connect(var0).syncUninterruptibly();
      return var1;
   }

   public void a(SecretKey var1) {
      this.o = true;
      this.k.pipeline().addBefore("splitter", "decrypt", new eg(ng.a(2, var1)));
      this.k.pipeline().addBefore("prepender", "encrypt", new eh(ng.a(1, var1)));
   }

   public boolean f() {
      return this.o;
   }

   public boolean g() {
      return this.k != null && this.k.isOpen();
   }

   public boolean h() {
      return this.k == null;
   }

   public ep i() {
      return this.m;
   }

   public eu j() {
      return this.n;
   }

   public void k() {
      this.k.config().setAutoRead(false);
   }

   public void a(int var1) {
      if (var1 >= 0) {
         if (this.k.pipeline().get("decompress") instanceof ei) {
            ((ei)this.k.pipeline().get("decompress")).a(var1);
         } else {
            this.k.pipeline().addBefore("decoder", "decompress", new ei(var1));
         }

         if (this.k.pipeline().get("compress") instanceof ej) {
            ((ej)this.k.pipeline().get("decompress")).a(var1);
         } else {
            this.k.pipeline().addBefore("encoder", "compress", new ej(var1));
         }
      } else {
         if (this.k.pipeline().get("decompress") instanceof ei) {
            this.k.pipeline().remove("decompress");
         }

         if (this.k.pipeline().get("compress") instanceof ej) {
            this.k.pipeline().remove("compress");
         }
      }

   }

   public void l() {
      if (this.k != null && !this.k.isOpen()) {
         if (!this.p) {
            this.p = true;
            if (this.j() != null) {
               this.i().a(this.j());
            } else if (this.i() != null) {
               this.i().a(new fa("Disconnected"));
            }
         } else {
            g.warn("handleDisconnection() called twice");
         }

      }
   }

   // $FF: synthetic method
   protected void channelRead0(ChannelHandlerContext var1, Object var2) throws Exception {
      this.a(var1, (ff)var2);
   }

   static {
      b = MarkerManager.getMarker("NETWORK_PACKETS", a);
      c = AttributeKey.valueOf("protocol");
      d = new no<NioEventLoopGroup>() {
         protected NioEventLoopGroup a() {
            return new NioEventLoopGroup(0, (new ThreadFactoryBuilder()).setNameFormat("Netty Client IO #%d").setDaemon(true).build());
         }

         // $FF: synthetic method
         protected Object b() {
            return this.a();
         }
      };
      e = new no<EpollEventLoopGroup>() {
         protected EpollEventLoopGroup a() {
            return new EpollEventLoopGroup(0, (new ThreadFactoryBuilder()).setNameFormat("Netty Epoll Client IO #%d").setDaemon(true).build());
         }

         // $FF: synthetic method
         protected Object b() {
            return this.a();
         }
      };
      f = new no<LocalEventLoopGroup>() {
         protected LocalEventLoopGroup a() {
            return new LocalEventLoopGroup(0, (new ThreadFactoryBuilder()).setNameFormat("Netty Local Client IO #%d").setDaemon(true).build());
         }

         // $FF: synthetic method
         protected Object b() {
            return this.a();
         }
      };
   }

   static class a {
      private final ff a;
      private final GenericFutureListener<? extends Future<? super Void>>[] b;

      public a(ff var1, GenericFutureListener<? extends Future<? super Void>>... var2) {
         this.a = var1;
         this.b = var2;
      }
   }
}
