public class bjz extends bjo<tw> {
   private static final jy a = new jy("textures/entity/snowman.png");

   public bjz(biu var1) {
      super(var1, new bcd(), 0.5F);
      this.a((blb)(new ble(this)));
   }

   protected jy a(tw var1) {
      return a;
   }

   public bcd g() {
      return (bcd)super.b();
   }

   // $FF: synthetic method
   public bbo b() {
      return this.g();
   }
}
