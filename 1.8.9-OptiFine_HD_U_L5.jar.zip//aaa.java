public class aaa extends yo {
   private final ahs b;

   public aaa(ahs var1) {
      super(var1);
      this.b = var1;
      this.d(0);
      this.a(true);
   }

   public int a(int var1) {
      return var1 | 4;
   }

   public int a(zx var1, int var2) {
      return this.b.h(this.b.a(var1.i()));
   }

   public String e_(zx var1) {
      return super.a() + "." + this.b.b(var1.i()).d();
   }
}
