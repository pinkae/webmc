public class alb extends akw implements km {
   public void c() {
      if (this.b != null && !this.b.D && this.b.K() % 20L == 0L) {
         this.e = this.w();
         if (this.e instanceof aga) {
            ((aga)this.e).f(this.b, this.c);
         }
      }

   }
}
