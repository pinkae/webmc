import com.google.common.base.Function;

public class aae extends yo {
   protected final afh b;
   protected final Function<zx, String> c;

   public aae(afh var1, afh var2, Function<zx, String> var3) {
      super(var1);
      this.b = var2;
      this.c = var3;
      this.d(0);
      this.a(true);
   }

   public aae(afh var1, afh var2, final String[] var3) {
      this(var1, var2, new Function<zx, String>() {
         public String a(zx var1) {
            int var2 = var1.i();
            if (var2 < 0 || var2 >= var3.length) {
               var2 = 0;
            }

            return var3[var2];
         }

         // $FF: synthetic method
         public Object apply(Object var1) {
            return this.a((zx)var1);
         }
      });
   }

   public int a(int var1) {
      return var1;
   }

   public String e_(zx var1) {
      return super.a() + "." + (String)this.c.apply(var1);
   }
}
