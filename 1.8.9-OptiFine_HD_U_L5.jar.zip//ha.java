import java.io.IOException;

public class ha implements ff<fj> {
   private int a;
   private cj b;

   public ha() {
   }

   public ha(wn var1, cj var2) {
      this.a = var1.F();
      this.b = var2;
   }

   public void a(em var1) throws IOException {
      this.a = var1.e();
      this.b = var1.c();
   }

   public void b(em var1) throws IOException {
      var1.b(this.a);
      var1.a(this.b);
   }

   public void a(fj var1) {
      var1.a(this);
   }

   public wn a(adm var1) {
      return (wn)var1.a(this.a);
   }

   public cj a() {
      return this.b;
   }
}
