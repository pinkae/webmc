import java.io.IOException;

public class il implements ff<ic> {
   private int a;

   public il() {
   }

   public il(int var1) {
      this.a = var1;
   }

   public void a(ic var1) {
      var1.a(this);
   }

   public void a(em var1) throws IOException {
      this.a = var1.readByte();
   }

   public void b(em var1) throws IOException {
      var1.writeByte(this.a);
   }
}
