import java.io.IOException;

public class jj implements ff<jf> {
   private eu a;

   public jj() {
   }

   public jj(eu var1) {
      this.a = var1;
   }

   public void a(em var1) throws IOException {
      this.a = var1.d();
   }

   public void b(em var1) throws IOException {
      var1.a(this.a);
   }

   public void a(jf var1) {
      var1.a(this);
   }

   public eu a() {
      return this.a;
   }
}
