import java.util.Random;

public class afm extends afh {
   protected afm() {
      this(arm.k);
   }

   protected afm(arm var1) {
      this(var1, var1.r());
   }

   protected afm(arm var1, arn var2) {
      super(var1, var2);
      this.a(true);
      float var3 = 0.2F;
      this.a(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, var3 * 3.0F, 0.5F + var3);
      this.a(yz.c);
   }

   public boolean d(adm var1, cj var2) {
      return super.d(var1, var2) && this.c(var1.p(var2.b()).c());
   }

   protected boolean c(afh var1) {
      return var1 == afi.c || var1 == afi.d || var1 == afi.ak;
   }

   public void a(adm var1, cj var2, alz var3, afh var4) {
      super.a(var1, var2, var3, var4);
      this.e(var1, var2, var3);
   }

   public void b(adm var1, cj var2, alz var3, Random var4) {
      this.e(var1, var2, var3);
   }

   protected void e(adm var1, cj var2, alz var3) {
      if (!this.f(var1, var2, var3)) {
         this.b(var1, var2, var3, 0);
         var1.a((cj)var2, (alz)afi.a.Q(), 3);
      }

   }

   public boolean f(adm var1, cj var2, alz var3) {
      return this.c(var1.p(var2.b()).c());
   }

   public aug a(adm var1, cj var2, alz var3) {
      return null;
   }

   public boolean c() {
      return false;
   }

   public boolean d() {
      return false;
   }

   public adf m() {
      return adf.c;
   }
}
