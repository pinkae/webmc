import java.util.Random;

public interface afj {
   boolean a(adm var1, cj var2, alz var3, boolean var4);

   boolean a(adm var1, Random var2, cj var3, alz var4);

   void b(adm var1, Random var2, cj var3, alz var4);
}
