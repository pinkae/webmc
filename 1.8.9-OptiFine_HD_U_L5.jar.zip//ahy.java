import java.util.Random;

public class ahy extends afc {
   protected ahy() {
      super(arm.e);
   }

   public akw a(adm var1, int var2) {
      return new all();
   }

   public zw a(alz var1, Random var2, int var3) {
      return null;
   }

   public int a(Random var1) {
      return 0;
   }

   public void a(adm var1, cj var2, alz var3, float var4, int var5) {
      super.a(var1, var2, var3, var4, var5);
      int var6 = 15 + var1.s.nextInt(15) + var1.s.nextInt(15);
      this.b(var1, var2, var6);
   }

   public boolean c() {
      return false;
   }

   public int b() {
      return 3;
   }

   public adf m() {
      return adf.c;
   }

   public zw c(adm var1, cj var2) {
      return null;
   }
}
