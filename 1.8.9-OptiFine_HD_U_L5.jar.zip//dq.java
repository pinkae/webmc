import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class dq extends eb {
   dq() {
   }

   void a(DataInput var1, int var2, dw var3) throws IOException {
      var3.a(64L);
   }

   void a(DataOutput var1) throws IOException {
   }

   public byte a() {
      return 0;
   }

   public String toString() {
      return "END";
   }

   public eb b() {
      return new dq();
   }
}
