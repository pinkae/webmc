public class bmg extends RuntimeException {
   private final bmf.a a;

   public bmg(bmf.a var1, String var2) {
      super(var2);
      this.a = var1;
   }
}
