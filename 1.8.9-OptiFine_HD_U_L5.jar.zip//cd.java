public class cd extends bz {
   public cd() {
      this("commands.generic.player.notFound");
   }

   public cd(String var1, Object... var2) {
      super(var1, var2);
   }
}
