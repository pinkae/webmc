public class yw extends zw {
   public yw() {
      this.a(yz.e);
      this.c(1);
      this.d(25);
   }

   public boolean w_() {
      return true;
   }

   public boolean e() {
      return true;
   }

   public zx a(zx var1, adm var2, wn var3) {
      if (var3.au() && var3.m instanceof tt) {
         tt var4 = (tt)var3.m;
         if (var4.cm().h() && var1.j() - var1.i() >= 7) {
            var4.cm().g();
            var1.a(7, (pr)var3);
            if (var1.b == 0) {
               zx var5 = new zx(zy.aR);
               var5.d(var1.o());
               return var5;
            }
         }
      }

      var3.b(na.ad[zw.b((zw)this)]);
      return var1;
   }
}
