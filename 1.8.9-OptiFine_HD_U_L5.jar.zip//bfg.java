public class bfg {
   private final bfd[] a = new bfd[adf.values().length];

   public bfg() {
      this.a[adf.a.ordinal()] = new bfd(2097152);
      this.a[adf.c.ordinal()] = new bfd(131072);
      this.a[adf.b.ordinal()] = new bfd(131072);
      this.a[adf.d.ordinal()] = new bfd(262144);
   }

   public bfd a(adf var1) {
      return this.a[var1.ordinal()];
   }

   public bfd a(int var1) {
      return this.a[var1];
   }
}
