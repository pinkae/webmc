public class acl extends oa.a {
   public final aci b;
   public final int c;

   public acl(aci var1, int var2) {
      super(var1.d());
      this.b = var1;
      this.c = var2;
   }
}
