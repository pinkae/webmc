public class wg implements acy {
   private ya a;
   private wn b;
   private ada c;
   private eu d;

   public wg(wn var1, eu var2) {
      this.b = var1;
      this.d = var2;
      this.a = new ya(var1, this);
   }

   public wn v_() {
      return this.b;
   }

   public void a_(wn var1) {
   }

   public ada b_(wn var1) {
      return this.c;
   }

   public void a(ada var1) {
      this.c = var1;
   }

   public void a(acz var1) {
      var1.g();
   }

   public void a_(zx var1) {
   }

   public eu f_() {
      return (eu)(this.d != null ? this.d : new fb("entity.Villager.name", new Object[0]));
   }
}
