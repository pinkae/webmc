import java.io.IOException;

public class ig implements ff<ic> {
   private ig.a a;

   public ig() {
   }

   public ig(ig.a var1) {
      this.a = var1;
   }

   public void a(em var1) throws IOException {
      this.a = (ig.a)var1.a(ig.a.class);
   }

   public void b(em var1) throws IOException {
      var1.a((Enum)this.a);
   }

   public void a(ic var1) {
      var1.a(this);
   }

   public ig.a a() {
      return this.a;
   }

   public static enum a {
      a,
      b,
      c;
   }
}
