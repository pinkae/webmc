public class bkd extends bkc<xc> {
   public bkd(biu var1, bjh var2) {
      super(var1, zy.bz, var2);
   }

   public zx a(xc var1) {
      return new zx(this.a, 1, var1.o());
   }

   // $FF: synthetic method
   public zx d(pk var1) {
      return this.a((xc)var1);
   }
}
