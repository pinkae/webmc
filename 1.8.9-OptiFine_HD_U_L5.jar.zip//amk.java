import com.google.common.collect.ImmutableSet;
import java.util.Collection;

public class amk extends amj<Boolean> {
   private final ImmutableSet<Boolean> a = ImmutableSet.of(true, false);

   protected amk(String var1) {
      super(var1, Boolean.class);
   }

   public Collection<Boolean> c() {
      return this.a;
   }

   public static amk a(String var0) {
      return new amk(var0);
   }

   public String a(Boolean var1) {
      return var1.toString();
   }
}
