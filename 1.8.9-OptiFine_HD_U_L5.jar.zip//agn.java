import java.util.List;
import java.util.Random;

public class agn extends afc {
   protected agn(arm var1) {
      super(var1);
      this.a(1.0F);
   }

   public akw a(adm var1, int var2) {
      return new alp();
   }

   public void a(adq var1, cj var2) {
      float var3 = 0.0625F;
      this.a(0.0F, 0.0F, 0.0F, 1.0F, var3, 1.0F);
   }

   public boolean a(adq var1, cj var2, cq var3) {
      return var3 == cq.a ? super.a(var1, var2, var3) : false;
   }

   public void a(adm var1, cj var2, alz var3, aug var4, List<aug> var5, pk var6) {
   }

   public boolean c() {
      return false;
   }

   public boolean d() {
      return false;
   }

   public int a(Random var1) {
      return 0;
   }

   public void a(adm var1, cj var2, alz var3, pk var4) {
      if (var4.m == null && var4.l == null && !var1.D) {
         var4.c(1);
      }

   }

   public void c(adm var1, cj var2, alz var3, Random var4) {
      double var5 = (double)((float)var2.n() + var4.nextFloat());
      double var7 = (double)((float)var2.o() + 0.8F);
      double var9 = (double)((float)var2.p() + var4.nextFloat());
      double var11 = 0.0D;
      double var13 = 0.0D;
      double var15 = 0.0D;
      var1.a(cy.l, var5, var7, var9, var11, var13, var15);
   }

   public zw c(adm var1, cj var2) {
      return null;
   }

   public arn g(alz var1) {
      return arn.E;
   }
}
