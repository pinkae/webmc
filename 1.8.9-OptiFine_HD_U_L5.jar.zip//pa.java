public class pa extends pe {
   protected pa(int var1, jy var2, boolean var3, int var4) {
      super(var1, var2, var3, var4);
   }

   public void a(pr var1, qf var2, int var3) {
      var1.m(var1.bN() - (float)(4 * (var3 + 1)));
      super.a(var1, var2, var3);
   }

   public void b(pr var1, qf var2, int var3) {
      var1.m(var1.bN() + (float)(4 * (var3 + 1)));
      super.b(var1, var2, var3);
   }
}
