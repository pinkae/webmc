public class aas extends zw {
   public boolean f(zx var1) {
      return true;
   }
}
