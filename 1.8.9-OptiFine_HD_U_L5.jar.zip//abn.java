public class abn {
   public void a(abt var1) {
      var1.b(new zx(zy.A), afi.P, afi.Q, zy.z);
      var1.a(new zx(zy.bc, 8), "#X#", 'X', new zx(zy.aW, 1, zd.m.b()), '#', zy.O);
      var1.a(new zx(zy.bq), " R ", "CPM", " B ", 'R', new zx(zy.bp), 'C', zy.bR, 'P', zy.bT, 'M', afi.P, 'B', zy.z);
      var1.a(new zx(zy.bq), " R ", "CPD", " B ", 'R', new zx(zy.bp), 'C', zy.bR, 'P', zy.bT, 'D', afi.Q, 'B', zy.z);
      var1.a(new zx(afi.bk), "MMM", "MMM", "MMM", 'M', zy.bf);
      var1.a(new zx(zy.bh), "M", 'M', zy.bf);
      var1.a(new zx(zy.bg, 4), "M", 'M', afi.aU);
      var1.b(new zx(zy.ca), afi.aU, zy.aY, zy.aP);
      var1.b(new zx(zy.bC), zy.bB, afi.P, zy.aY);
      var1.b(new zx(zy.bD, 2), zy.bv);
      var1.b(new zx(zy.bE), zy.bD, zy.aM);
   }
}
