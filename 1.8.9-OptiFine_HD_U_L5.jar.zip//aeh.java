public class aeh extends ady {
   public aeh(int var1) {
      super(var1);
      this.at.clear();
      this.au.clear();
      this.av.clear();
      this.aw.clear();
      this.at.add(new ady.c(vr.class, 50, 4, 4));
      this.at.add(new ady.c(vw.class, 100, 4, 4));
      this.at.add(new ady.c(vu.class, 1, 4, 4));
   }
}
