public class aka extends afn {
   protected aka() {
      super(false);
   }
}
