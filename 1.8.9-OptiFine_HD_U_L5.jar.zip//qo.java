public class qo {
   private ps b;
   protected boolean a;

   public qo(ps var1) {
      this.b = var1;
   }

   public void a() {
      this.a = true;
   }

   public void b() {
      this.b.i(this.a);
      this.a = false;
   }
}
