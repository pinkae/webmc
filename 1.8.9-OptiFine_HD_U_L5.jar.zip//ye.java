public class ye implements og {
   private zx[] a = new zx[1];

   public int o_() {
      return 1;
   }

   public zx a(int var1) {
      return this.a[0];
   }

   public String e_() {
      return "Result";
   }

   public boolean l_() {
      return false;
   }

   public eu f_() {
      return (eu)(this.l_() ? new fa(this.e_()) : new fb(this.e_(), new Object[0]));
   }

   public zx a(int var1, int var2) {
      if (this.a[0] != null) {
         zx var3 = this.a[0];
         this.a[0] = null;
         return var3;
      } else {
         return null;
      }
   }

   public zx b(int var1) {
      if (this.a[0] != null) {
         zx var2 = this.a[0];
         this.a[0] = null;
         return var2;
      } else {
         return null;
      }
   }

   public void a(int var1, zx var2) {
      this.a[0] = var2;
   }

   public int q_() {
      return 64;
   }

   public void p_() {
   }

   public boolean a(wn var1) {
      return true;
   }

   public void b(wn var1) {
   }

   public void c(wn var1) {
   }

   public boolean b(int var1, zx var2) {
      return true;
   }

   public int a_(int var1) {
      return 0;
   }

   public void b(int var1, int var2) {
   }

   public int g() {
      return 0;
   }

   public void l() {
      for(int var1 = 0; var1 < this.a.length; ++var1) {
         this.a[var1] = null;
      }

   }
}
