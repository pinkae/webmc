public class ald extends alc {
   public String e_() {
      return this.l_() ? this.a : "container.dropper";
   }

   public String k() {
      return "minecraft:dropper";
   }
}
