import java.util.Random;

public class ajk extends afh {
   public ajk(arm var1) {
      super(var1);
      this.a(yz.b);
   }

   public int a(Random var1) {
      return 2 + var1.nextInt(2);
   }

   public int a(int var1, Random var2) {
      return ns.a(this.a(var2) + var2.nextInt(var1 + 1), 1, 5);
   }

   public zw a(alz var1, Random var2, int var3) {
      return zy.cD;
   }

   public arn g(alz var1) {
      return arn.p;
   }

   protected boolean I() {
      return true;
   }
}
