import java.util.Random;

public class ahf extends agr {
   public zw a(alz var1, Random var2, int var3) {
      if (var3 > 3) {
         var3 = 3;
      }

      return var2.nextInt(10 - var3 * 3) == 0 ? zy.ak : zw.a((afh)this);
   }

   public arn g(alz var1) {
      return arn.m;
   }
}
