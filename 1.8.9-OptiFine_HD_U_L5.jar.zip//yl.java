import com.google.common.collect.Sets;
import java.util.Set;

public class yl extends za {
   private static final Set<afh> c;

   protected yl(zw.a var1) {
      super(3.0F, var1, c);
   }

   public float a(zx var1, afh var2) {
      return var2.t() != arm.d && var2.t() != arm.k && var2.t() != arm.l ? super.a(var1, var2) : this.a;
   }

   static {
      c = Sets.newHashSet(new afh[]{afi.f, afi.X, afi.r, afi.s, afi.ae, afi.aU, afi.aZ, afi.bk, afi.au});
   }
}
