public class bjw extends bjo<vz> {
   private static final jy a = new jy("textures/entity/silverfish.png");

   public bjw(biu var1) {
      super(var1, new bby(), 0.3F);
   }

   protected float a(vz var1) {
      return 180.0F;
   }

   protected jy b(vz var1) {
      return a;
   }

   // $FF: synthetic method
   protected float b(pr var1) {
      return this.a((vz)var1);
   }

   // $FF: synthetic method
   protected jy a(pk var1) {
      return this.b((vz)var1);
   }
}
