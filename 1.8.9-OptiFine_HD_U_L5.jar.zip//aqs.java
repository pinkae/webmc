public class aqs extends ate {
   private dn b = new dn();

   public aqs(String var1) {
      super(var1);
   }

   public void a(dn var1) {
      this.b = var1.m("Features");
   }

   public void b(dn var1) {
      var1.a((String)"Features", (eb)this.b);
   }

   public void a(dn var1, int var2, int var3) {
      this.b.a((String)b(var2, var3), (eb)var1);
   }

   public static String b(int var0, int var1) {
      return "[" + var0 + "," + var1 + "]";
   }

   public dn a() {
      return this.b;
   }
}
