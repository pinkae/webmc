public class xt extends yg {
   public xt(og var1, int var2, int var3, int var4) {
      super(var1, var2, var3, var4);
   }

   public boolean a(zx var1) {
      return alh.c(var1) || c_(var1);
   }

   public int b(zx var1) {
      return c_(var1) ? 1 : super.b(var1);
   }

   public static boolean c_(zx var0) {
      return var0 != null && var0.b() != null && var0.b() == zy.aw;
   }
}
