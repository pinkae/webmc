public interface ud {
   adm a();

   boolean a(ue var1, ow var2, float var3);
}
