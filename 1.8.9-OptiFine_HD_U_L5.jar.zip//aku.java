import com.google.common.collect.Lists;
import java.util.List;

public class aku extends akw {
   private int a;
   private du f;
   private boolean g;
   private List<aku.a> h;
   private List<zd> i;
   private String j;

   public void a(zx var1) {
      this.f = null;
      if (var1.n() && var1.o().b("BlockEntityTag", 10)) {
         dn var2 = var1.o().m("BlockEntityTag");
         if (var2.c("Patterns")) {
            this.f = (du)var2.c("Patterns", 10).b();
         }

         if (var2.b("Base", 99)) {
            this.a = var2.f("Base");
         } else {
            this.a = var1.i() & 15;
         }
      } else {
         this.a = var1.i() & 15;
      }

      this.h = null;
      this.i = null;
      this.j = "";
      this.g = true;
   }

   public void b(dn var1) {
      super.b(var1);
      a(var1, this.a, this.f);
   }

   public static void a(dn var0, int var1, du var2) {
      var0.a("Base", var1);
      if (var2 != null) {
         var0.a((String)"Patterns", (eb)var2);
      }

   }

   public void a(dn var1) {
      super.a(var1);
      this.a = var1.f("Base");
      this.f = var1.c("Patterns", 10);
      this.h = null;
      this.i = null;
      this.j = null;
      this.g = true;
   }

   public ff y_() {
      dn var1 = new dn();
      this.b(var1);
      return new ft(this.c, 6, var1);
   }

   public int b() {
      return this.a;
   }

   public static int b(zx var0) {
      dn var1 = var0.a("BlockEntityTag", false);
      return var1 != null && var1.c("Base") ? var1.f("Base") : var0.i();
   }

   public static int c(zx var0) {
      dn var1 = var0.a("BlockEntityTag", false);
      return var1 != null && var1.c("Patterns") ? var1.c("Patterns", 10).c() : 0;
   }

   public List<aku.a> c() {
      this.h();
      return this.h;
   }

   public du d() {
      return this.f;
   }

   public List<zd> e() {
      this.h();
      return this.i;
   }

   public String g() {
      this.h();
      return this.j;
   }

   private void h() {
      if (this.h == null || this.i == null || this.j == null) {
         if (!this.g) {
            this.j = "";
         } else {
            this.h = Lists.newArrayList();
            this.i = Lists.newArrayList();
            this.h.add(aku.a.a);
            this.i.add(zd.a(this.a));
            this.j = "b" + this.a;
            if (this.f != null) {
               for(int var1 = 0; var1 < this.f.c(); ++var1) {
                  dn var2 = this.f.b(var1);
                  aku.a var3 = aku.a.a(var2.j("Pattern"));
                  if (var3 != null) {
                     this.h.add(var3);
                     int var4 = var2.f("Color");
                     this.i.add(zd.a(var4));
                     this.j = this.j + var3.b() + var4;
                  }
               }
            }

         }
      }
   }

   public static void e(zx var0) {
      dn var1 = var0.a("BlockEntityTag", false);
      if (var1 != null && var1.b("Patterns", 9)) {
         du var2 = var1.c("Patterns", 10);
         if (var2.c() > 0) {
            var2.a(var2.c() - 1);
            if (var2.c_()) {
               var0.o().o("BlockEntityTag");
               if (var0.o().c_()) {
                  var0.d((dn)null);
               }
            }

         }
      }
   }

   public static enum a {
      a("base", "b"),
      b("square_bottom_left", "bl", "   ", "   ", "#  "),
      c("square_bottom_right", "br", "   ", "   ", "  #"),
      d("square_top_left", "tl", "#  ", "   ", "   "),
      e("square_top_right", "tr", "  #", "   ", "   "),
      f("stripe_bottom", "bs", "   ", "   ", "###"),
      g("stripe_top", "ts", "###", "   ", "   "),
      h("stripe_left", "ls", "#  ", "#  ", "#  "),
      i("stripe_right", "rs", "  #", "  #", "  #"),
      j("stripe_center", "cs", " # ", " # ", " # "),
      k("stripe_middle", "ms", "   ", "###", "   "),
      l("stripe_downright", "drs", "#  ", " # ", "  #"),
      m("stripe_downleft", "dls", "  #", " # ", "#  "),
      n("small_stripes", "ss", "# #", "# #", "   "),
      o("cross", "cr", "# #", " # ", "# #"),
      p("straight_cross", "sc", " # ", "###", " # "),
      q("triangle_bottom", "bt", "   ", " # ", "# #"),
      r("triangle_top", "tt", "# #", " # ", "   "),
      s("triangles_bottom", "bts", "   ", "# #", " # "),
      t("triangles_top", "tts", " # ", "# #", "   "),
      u("diagonal_left", "ld", "## ", "#  ", "   "),
      v("diagonal_up_right", "rd", "   ", "  #", " ##"),
      w("diagonal_up_left", "lud", "   ", "#  ", "## "),
      x("diagonal_right", "rud", " ##", "  #", "   "),
      y("circle", "mc", "   ", " # ", "   "),
      z("rhombus", "mr", " # ", "# #", " # "),
      A("half_vertical", "vh", "## ", "## ", "## "),
      B("half_horizontal", "hh", "###", "###", "   "),
      C("half_vertical_right", "vhr", " ##", " ##", " ##"),
      D("half_horizontal_bottom", "hhb", "   ", "###", "###"),
      E("border", "bo", "###", "# #", "###"),
      F("curly_border", "cbo", new zx(afi.bn)),
      G("creeper", "cre", new zx(zy.bX, 1, 4)),
      H("gradient", "gra", "# #", " # ", " # "),
      I("gradient_up", "gru", " # ", " # ", "# #"),
      J("bricks", "bri", new zx(afi.V)),
      K("skull", "sku", new zx(zy.bX, 1, 1)),
      L("flower", "flo", new zx(afi.O, 1, agw.a.j.b())),
      M("mojang", "moj", new zx(zy.ao, 1, 1));

      private String N;
      private String O;
      private String[] P;
      private zx Q;

      private a(String var3, String var4) {
         this.P = new String[3];
         this.N = var3;
         this.O = var4;
      }

      private a(String var3, String var4, zx var5) {
         this(var3, var4);
         this.Q = var5;
      }

      private a(String var3, String var4, String var5, String var6, String var7) {
         this(var3, var4);
         this.P[0] = var5;
         this.P[1] = var6;
         this.P[2] = var7;
      }

      public String a() {
         return this.N;
      }

      public String b() {
         return this.O;
      }

      public String[] c() {
         return this.P;
      }

      public boolean d() {
         return this.Q != null || this.P[0] != null;
      }

      public boolean e() {
         return this.Q != null;
      }

      public zx f() {
         return this.Q;
      }

      public static aku.a a(String var0) {
         aku.a[] var1 = values();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            aku.a var4 = var1[var3];
            if (var4.O.equals(var0)) {
               return var4;
            }
         }

         return null;
      }
   }
}
