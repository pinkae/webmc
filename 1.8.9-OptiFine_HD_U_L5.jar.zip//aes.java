public class aes extends ady {
   public aes(int var1) {
      super(var1);
      this.au.clear();
      this.ak = afi.b.Q();
      this.al = afi.b.Q();
      this.as.A = -999;
      this.as.D = 0;
      this.as.F = 0;
      this.as.G = 0;
   }
}
