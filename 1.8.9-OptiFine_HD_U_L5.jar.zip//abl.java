public class abl {
   public void a(abt var1) {
      int var2;
      for(var2 = 0; var2 < 16; ++var2) {
         var1.b(new zx(afi.L, 1, var2), new zx(zy.aW, 1, 15 - var2), new zx(zw.a(afi.L), 1, 0));
         var1.a(new zx(afi.cu, 8, 15 - var2), "###", "#X#", "###", '#', new zx(afi.cz), 'X', new zx(zy.aW, 1, var2));
         var1.a(new zx(afi.cG, 8, 15 - var2), "###", "#X#", "###", '#', new zx(afi.w), 'X', new zx(zy.aW, 1, var2));
         var1.a(new zx(afi.cH, 16, var2), "###", "###", '#', new zx(afi.cG, 1, var2));
      }

      var1.b(new zx(zy.aW, 1, zd.e.b()), new zx(afi.N, 1, agw.a.a.b()));
      var1.b(new zx(zy.aW, 1, zd.o.b()), new zx(afi.O, 1, agw.a.b.b()));
      var1.b(new zx(zy.aW, 3, zd.a.b()), zy.aX);
      var1.b(new zx(zy.aW, 2, zd.g.b()), new zx(zy.aW, 1, zd.o.b()), new zx(zy.aW, 1, zd.a.b()));
      var1.b(new zx(zy.aW, 2, zd.b.b()), new zx(zy.aW, 1, zd.o.b()), new zx(zy.aW, 1, zd.e.b()));
      var1.b(new zx(zy.aW, 2, zd.f.b()), new zx(zy.aW, 1, zd.n.b()), new zx(zy.aW, 1, zd.a.b()));
      var1.b(new zx(zy.aW, 2, zd.h.b()), new zx(zy.aW, 1, zd.p.b()), new zx(zy.aW, 1, zd.a.b()));
      var1.b(new zx(zy.aW, 2, zd.i.b()), new zx(zy.aW, 1, zd.h.b()), new zx(zy.aW, 1, zd.a.b()));
      var1.b(new zx(zy.aW, 3, zd.i.b()), new zx(zy.aW, 1, zd.p.b()), new zx(zy.aW, 1, zd.a.b()), new zx(zy.aW, 1, zd.a.b()));
      var1.b(new zx(zy.aW, 2, zd.d.b()), new zx(zy.aW, 1, zd.l.b()), new zx(zy.aW, 1, zd.a.b()));
      var1.b(new zx(zy.aW, 2, zd.j.b()), new zx(zy.aW, 1, zd.l.b()), new zx(zy.aW, 1, zd.n.b()));
      var1.b(new zx(zy.aW, 2, zd.k.b()), new zx(zy.aW, 1, zd.l.b()), new zx(zy.aW, 1, zd.o.b()));
      var1.b(new zx(zy.aW, 2, zd.c.b()), new zx(zy.aW, 1, zd.k.b()), new zx(zy.aW, 1, zd.g.b()));
      var1.b(new zx(zy.aW, 3, zd.c.b()), new zx(zy.aW, 1, zd.l.b()), new zx(zy.aW, 1, zd.o.b()), new zx(zy.aW, 1, zd.g.b()));
      var1.b(new zx(zy.aW, 4, zd.c.b()), new zx(zy.aW, 1, zd.l.b()), new zx(zy.aW, 1, zd.o.b()), new zx(zy.aW, 1, zd.o.b()), new zx(zy.aW, 1, zd.a.b()));
      var1.b(new zx(zy.aW, 1, zd.d.b()), new zx(afi.O, 1, agw.a.c.b()));
      var1.b(new zx(zy.aW, 1, zd.c.b()), new zx(afi.O, 1, agw.a.d.b()));
      var1.b(new zx(zy.aW, 1, zd.i.b()), new zx(afi.O, 1, agw.a.e.b()));
      var1.b(new zx(zy.aW, 1, zd.o.b()), new zx(afi.O, 1, agw.a.f.b()));
      var1.b(new zx(zy.aW, 1, zd.b.b()), new zx(afi.O, 1, agw.a.g.b()));
      var1.b(new zx(zy.aW, 1, zd.i.b()), new zx(afi.O, 1, agw.a.h.b()));
      var1.b(new zx(zy.aW, 1, zd.g.b()), new zx(afi.O, 1, agw.a.i.b()));
      var1.b(new zx(zy.aW, 1, zd.i.b()), new zx(afi.O, 1, agw.a.j.b()));
      var1.b(new zx(zy.aW, 2, zd.e.b()), new zx(afi.cF, 1, agi.b.a.a()));
      var1.b(new zx(zy.aW, 2, zd.c.b()), new zx(afi.cF, 1, agi.b.b.a()));
      var1.b(new zx(zy.aW, 2, zd.o.b()), new zx(afi.cF, 1, agi.b.e.a()));
      var1.b(new zx(zy.aW, 2, zd.g.b()), new zx(afi.cF, 1, agi.b.f.a()));

      for(var2 = 0; var2 < 16; ++var2) {
         var1.a(new zx(afi.cy, 3, var2), "##", '#', new zx(afi.L, 1, var2));
      }

   }
}
