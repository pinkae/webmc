public class ark extends arm {
   public ark(arn var1) {
      super(var1);
      this.i();
   }

   public boolean a() {
      return false;
   }

   public boolean b() {
      return false;
   }

   public boolean c() {
      return false;
   }
}
