public abstract class tj extends ps implements pi {
   public tj(adm var1) {
      super(var1);
   }

   public boolean cb() {
      return false;
   }

   protected boolean a(wn var1) {
      return false;
   }
}
