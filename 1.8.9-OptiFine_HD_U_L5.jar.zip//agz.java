public class agz extends akb {
   public boolean l() {
      return true;
   }
}
