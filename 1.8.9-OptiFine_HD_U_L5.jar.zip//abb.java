public class abb extends aaz {
   public abb(afh var1) {
      super(var1, false);
   }

   public zx a(zx var1, adm var2, wn var3) {
      auh var4 = this.a(var2, var3, true);
      if (var4 == null) {
         return var1;
      } else {
         if (var4.a == auh.a.b) {
            cj var5 = var4.a();
            if (!var2.a(var3, var5)) {
               return var1;
            }

            if (!var3.a(var5.a(var4.b), var4.b, var1)) {
               return var1;
            }

            cj var6 = var5.a();
            alz var7 = var2.p(var5);
            if (var7.c().t() == arm.h && (Integer)var7.b(ahv.b) == 0 && var2.d(var6)) {
               var2.a(var6, afi.bx.Q());
               if (!var3.bA.d) {
                  --var1.b;
               }

               var3.b(na.ad[zw.b((zw)this)]);
            }
         }

         return var1;
      }
   }

   public int a(zx var1, int var2) {
      return afi.bx.h(afi.bx.a(var1.i()));
   }
}
