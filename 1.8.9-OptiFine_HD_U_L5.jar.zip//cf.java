public class cf extends cc {
   public cf(String var1, Object... var2) {
      super(var1, var2);
   }
}
