public class aaf extends zw {
   public aaf() {
      this.a(yz.i);
   }

   public boolean a(zx var1, wn var2, pr var3) {
      if (!var1.s()) {
         return false;
      } else if (var3 instanceof ps) {
         ps var4 = (ps)var3;
         var4.a((String)var1.q());
         var4.bX();
         --var1.b;
         return true;
      } else {
         return super.a(var1, var2, var3);
      }
   }
}
