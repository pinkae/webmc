public class bip extends biv<pk> {
   public bip(biu var1) {
      super(var1);
   }

   public void a(pk var1, double var2, double var4, double var6, float var8, float var9) {
      bfl.E();
      a(var1.aR(), var2 - var1.P, var4 - var1.Q, var6 - var1.R);
      bfl.F();
      super.a(var1, var2, var4, var6, var8, var9);
   }

   protected jy a(pk var1) {
      return null;
   }
}
