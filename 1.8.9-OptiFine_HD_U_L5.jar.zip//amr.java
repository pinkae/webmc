public enum amr {
   a(4259712),
   b(16724016),
   c(2138367);

   private final int d;

   private amr(int var3) {
      this.d = var3;
   }

   public int a() {
      return this.d;
   }
}
