public enum adf {
   a("Solid"),
   b("Mipped Cutout"),
   c("Cutout"),
   d("Translucent");

   private final String e;

   private adf(String var3) {
      this.e = var3;
   }

   public String toString() {
      return this.e;
   }
}
