public class bnq {
   private static bnt a;

   static void a(bnt var0) {
      a = var0;
   }

   public static String a(String var0, Object... var1) {
      return a.a(var0, var1);
   }
}
