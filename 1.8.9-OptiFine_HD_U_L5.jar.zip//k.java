import java.util.List;

public interface k extends Comparable<k> {
   String c();

   String c(m var1);

   List<String> b();

   void a(m var1, String[] var2) throws bz;

   boolean a(m var1);

   List<String> a(m var1, String[] var2, cj var3);

   boolean b(String[] var1, int var2);
}
