import com.google.common.collect.Maps;
import java.util.HashMap;

public class pv {
   private static final HashMap<Class, ps.a> a = Maps.newHashMap();

   public static ps.a a(Class var0) {
      return (ps.a)a.get(var0);
   }

   static {
      a.put(tk.class, ps.a.a);
      a.put(tn.class, ps.a.a);
      a.put(to.class, ps.a.a);
      a.put(tp.class, ps.a.a);
      a.put(tr.class, ps.a.a);
      a.put(ts.class, ps.a.a);
      a.put(tt.class, ps.a.a);
      a.put(tu.class, ps.a.a);
      a.put(tv.class, ps.a.a);
      a.put(tw.class, ps.a.a);
      a.put(tx.class, ps.a.c);
      a.put(ty.class, ps.a.a);
      a.put(ua.class, ps.a.a);
      a.put(wi.class, ps.a.a);
      a.put(ug.class, ps.a.a);
      a.put(uk.class, ps.a.a);
      a.put(vl.class, ps.a.a);
      a.put(vm.class, ps.a.a);
      a.put(vn.class, ps.a.a);
      a.put(vo.class, ps.a.a);
      a.put(vp.class, ps.a.a);
      a.put(vr.class, ps.a.a);
      a.put(vs.class, ps.a.a);
      a.put(vt.class, ps.a.c);
      a.put(vu.class, ps.a.a);
      a.put(vw.class, ps.a.a);
      a.put(vz.class, ps.a.a);
      a.put(wa.class, ps.a.a);
      a.put(wb.class, ps.a.a);
      a.put(wc.class, ps.a.a);
      a.put(wd.class, ps.a.a);
      a.put(we.class, ps.a.a);
   }
}
