import java.util.Map;

public interface bgy {
   Map<alz, bov> a(afh var1);
}
