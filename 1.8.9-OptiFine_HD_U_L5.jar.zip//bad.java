import com.mojang.authlib.GameProfile;

public class bad implements bah {
   private final GameProfile a;
   private final jy b;

   public bad(GameProfile var1) {
      this.a = var1;
      this.b = bet.c(var1.getName());
      bet.a(this.b, var1.getName());
   }

   public void a(baf var1) {
      ave.A().u().a((ff)(new iz(this.a.getId())));
   }

   public eu A_() {
      return new fa(this.a.getName());
   }

   public void a(float var1, int var2) {
      ave.A().P().a(this.b);
      bfl.c(1.0F, 1.0F, 1.0F, (float)var2 / 255.0F);
      avp.a(2, 2, 8.0F, 8.0F, 8, 8, 12, 12, 64.0F, 64.0F);
      avp.a(2, 2, 40.0F, 8.0F, 8, 8, 12, 12, 64.0F, 64.0F);
   }

   public boolean B_() {
      return true;
   }
}
