public enum zd implements nw {
   a(0, 15, "white", "white", arn.j, a.p),
   b(1, 14, "orange", "orange", arn.q, a.g),
   c(2, 13, "magenta", "magenta", arn.r, a.l),
   d(3, 12, "light_blue", "lightBlue", arn.s, a.j),
   e(4, 11, "yellow", "yellow", arn.t, a.o),
   f(5, 10, "lime", "lime", arn.u, a.k),
   g(6, 9, "pink", "pink", arn.v, a.n),
   h(7, 8, "gray", "gray", arn.w, a.i),
   i(8, 7, "silver", "silver", arn.x, a.h),
   j(9, 6, "cyan", "cyan", arn.y, a.d),
   k(10, 5, "purple", "purple", arn.z, a.f),
   l(11, 4, "blue", "blue", arn.A, a.b),
   m(12, 3, "brown", "brown", arn.B, a.g),
   n(13, 2, "green", "green", arn.C, a.c),
   o(14, 1, "red", "red", arn.D, a.e),
   p(15, 0, "black", "black", arn.E, a.a);

   private static final zd[] q = new zd[values().length];
   private static final zd[] r = new zd[values().length];
   private final int s;
   private final int t;
   private final String u;
   private final String v;
   private final arn w;
   private final a x;

   private zd(int var3, int var4, String var5, String var6, arn var7, a var8) {
      this.s = var3;
      this.t = var4;
      this.u = var5;
      this.v = var6;
      this.w = var7;
      this.x = var8;
   }

   public int a() {
      return this.s;
   }

   public int b() {
      return this.t;
   }

   public String d() {
      return this.v;
   }

   public arn e() {
      return this.w;
   }

   public static zd a(int var0) {
      if (var0 < 0 || var0 >= r.length) {
         var0 = 0;
      }

      return r[var0];
   }

   public static zd b(int var0) {
      if (var0 < 0 || var0 >= q.length) {
         var0 = 0;
      }

      return q[var0];
   }

   public String toString() {
      return this.v;
   }

   public String l() {
      return this.u;
   }

   static {
      zd[] var0 = values();
      int var1 = var0.length;

      for(int var2 = 0; var2 < var1; ++var2) {
         zd var3 = var0[var2];
         q[var3.a()] = var3;
         r[var3.b()] = var3;
      }

   }
}
