public class bit extends bjo<vp> {
   private static final jy a = new jy("textures/entity/endermite.png");

   public bit(biu var1) {
      super(var1, new bbe(), 0.3F);
   }

   protected float a(vp var1) {
      return 180.0F;
   }

   protected jy b(vp var1) {
      return a;
   }

   // $FF: synthetic method
   protected float b(pr var1) {
      return this.a((vp)var1);
   }

   // $FF: synthetic method
   protected jy a(pk var1) {
      return this.b((vp)var1);
   }
}
