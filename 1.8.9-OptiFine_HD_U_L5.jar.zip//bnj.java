public interface bnj {
   void a(bni var1);
}
